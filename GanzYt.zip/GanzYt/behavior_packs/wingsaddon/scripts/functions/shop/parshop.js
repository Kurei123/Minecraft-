import { world, system, Player } from '@minecraft/server'
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui'
import { getScore, metricNumbers } from "../../lib/tools.js"
        
const wingsName = [
  {
    textures: 'textures/ui/1',
    name: 'Lightning Wings',
    cost: 200000,
    tag: 'lightning'
  },
  {
    textures: 'textures/ui/2',
    name: 'Ice Wings',
    cost: 250000,
    tag: 'ice'
  },
  {
    textures: 'textures/ui/3',
    name: 'Fire Wings',
    cost: 300000,
    tag: 'fire'
  },
  {
    textures: 'textures/ui/4',
    name: 'Poison Wings',
    cost: 400000,
    tag: 'poison'
  },
  {
    textures: 'textures/ui/5',
    name: 'Griffin Wings',
    cost: 500000,
    tag: 'griffin'
  },
  {
    textures: 'textures/ui/6',
    name: 'Abyssal Wings',
    cost: 500000,
    tag: 'abyssal'
  },
  {
    textures: 'textures/ui/7',
    name: 'Red Wings',
    cost: 600000,
    tag: 'red'
  },
  {
    textures: 'textures/ui/8',
    name: 'Black Wings',
    cost: 600000,
    tag: 'black'
  },
  {
    textures: 'textures/ui/9',
    name: 'White Wings',
    cost: 600000,
    tag: 'white'
  },
];


//       HOW TO ADD MORE ARRAY?       \\

/*
{
    textures: 'textures/items/potion_bottle_nightVision.png',
    name: 'Night Vision',
    cost: 1000,
    effect: 'night_vision'
},
{
    textures: 'textures/items/potion_bottle_regeneration.png',
    name: 'Regeneration',
    cost: 1000,
    effect: 'regeneration'
},
*/

//COPY AND PASTE ON UNDER COMA!!



























system.runInterval(() => {
  for (let player of world.getPlayers()) {
    if (player.hasTag("wshop")) {
      parShop(player);
      player.runCommandAsync(`tag @s remove wshop`);
    }
  }
});

export function parShop(player) {
  const gui = new ActionFormData();
  gui.title(`WingsShop | Menu`);

  for (const effect of wingsName) {
    gui.button(`§l${effect.name}\n§r§b${metricNumbers(effect.cost)}`, `${effect.textures}`);
  }

  gui.button("§l§cBACK\n§r§oClick To Back");

  gui.show(player).then(result => {
    if (result.canceled) return;
    const effect = wingsName[result.selection];
    const money = getScore(player, "money");

    const brick = new MessageFormData();
    brick.title(`Confirm Buy`);
    brick.body(`§7Are you sure want buy §e${effect.name} §7for §e${effect.cost}`)
    brick.button1('Yes')
    brick.button2('No')
    
    brick.show(player).then(res => {
      if (res.canceled) return;

      const dataCost = effect.cost
   if (res.selection === 0) {
      if (money < dataCost) {
        player.sendMessage(`§cYour money is not enough, you need ${dataCost} money to buy`);
        player.playSound(`note.bass`);
      } else {
        player.runCommandAsync(`scoreboard players remove @s[scores={money=${dataCost}..}] money ${dataCost}`);
        player.addTag(`${effect.tag}`)
        player.sendMessage(`§7You have bought ${effect.name}`);
        player.playSound(`random.levelup`);
      }
     } else {
        player.sendMessage('§cCanceled Payment')
     }
    });
  });
}
