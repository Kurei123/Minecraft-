import { world, system } from "@minecraft/server";
import * as ui from "@minecraft/server-ui";

const config = {
    prefix: '-',
    adminTag: 'admin',
    adminItem: 'mcc:settings'
};

const uuidRanks = [
    "", "", "", "", "", "", "", "", 
    "", "", "", "", "", "", "", "", 
    "", "", "", "", ""
];

let customRankList = []; // Array untuk menyimpan custom rank

function setRank(player, rank) {
    if (player.getTags().find(tag => tag.startsWith('rank:'))) {
        const rankTags = player.getTags().filter(tag => tag.startsWith('rank:'));
        rankTags.forEach((tag) => player.removeTag(tag));
    }
    player.addTag(`rank:${rank}`);
    player.sendMessage(`§aSuccessfully changed your rank to: §2${rank}`);
}

function removeRank(player) {
    const rankTags = player.getTags().filter(tag => tag.startsWith('rank:'));
    if (rankTags.length > 0) {
        rankTags.forEach((tag) => player.removeTag(tag));
        player.sendMessage('§aSuccessfully removed your rank.');
    } else {
        player.sendMessage('§cYou don\'t have any rank to remove.');
    }
}

function getRank(player) {
    const allTags = player.getTags();
    const foundTag = allTags.find(tag => tag.startsWith('rank:'));
    if (!foundTag) return '§7Rakyat Biasa§r';
    return foundTag.substring(5); // Menghapus 'rank:' dari tag
}

world.beforeEvents.itemUse.subscribe((eventData) => {
    let item = eventData.itemStack;
    let player = eventData.source;

    if (item.typeId === config.adminItem && player.hasTag(config.adminTag)) {
        system.run(() => {
            openAdminPanel(player);
        });
    }
});

function openAdminPanel(player) {
    const panel = new ui.ActionFormData()
        .title("Admin Rank Panel")
        .body("Choose an action:")
        .button("Set Player Rank")
        .button("Remove Player Rank")
        .button("Add Custom Rank")
        .show(player)
        .then(response => {
            if (response.selection === 0) {
                openPlayerSelectionForRank(player);
            } else if (response.selection === 1) {
                openPlayerSelectionForRemoval(player);
            } else if (response.selection === 2) {
                addCustomRank(player);
            }
        });
}

function openPlayerSelectionForRank(player) {
    const players = world.getDimension('overworld').getPlayers();
    const playerNames = players.map(plr => plr.name);
    const rankNames = [...customRankList, ...uuidRanks];

    const playerForm = new ui.ModalFormData()
        .title("Select Player and Rank")
        .dropdown("Choose a player", playerNames)
        .dropdown("Choose a rank", rankNames)
        .show(player)
        .then(response => {
            if (response.formValues) {
                const [playerIndex, rankIndex] = response.formValues;
                const selectedPlayerName = playerNames[playerIndex];
                const selectedRank = rankNames[rankIndex];
                const selectedPlayer = players.find(plr => plr.name === selectedPlayerName);

                if (selectedPlayer) {
                    setRank(selectedPlayer, selectedRank);
                } else {
                    player.sendMessage('§cCouldn\'t find a player with that name.');
                }
            }
        });
}

function openPlayerSelectionForRemoval(player) {
    const players = world.getDimension('overworld').getPlayers();
    const playerNames = players.map(plr => plr.name);

    const playerForm = new ui.ModalFormData()
        .title("Select Player")
        .dropdown("Choose a player", playerNames)
        .show(player)
        .then(response => {
            if (response.formValues) {
                const [playerIndex] = response.formValues;
                const selectedPlayerName = playerNames[playerIndex];
                const selectedPlayer = players.find(plr => plr.name === selectedPlayerName);

                if (selectedPlayer) {
                    removeRank(selectedPlayer);
                } else {
                    player.sendMessage('§cCouldn\'t find a player with that name.');
                }
            }
        });
}

function addCustomRank(player) {
    const players = world.getDimension('overworld').getPlayers();
    const playerNames = players.map(plr => plr.name);

    const rankForm = new ui.ModalFormData()
        .title("Add Custom Rank")
        .dropdown("Choose a player", playerNames)
        .textField("Rank Name", "Enter the custom rank name")
        .show(player)
        .then(response => {
            if (response.formValues) {
                const [playerIndex, customRankName] = response.formValues;
                const selectedPlayerName = playerNames[playerIndex];
                const selectedPlayer = players.find(plr => plr.name === selectedPlayerName);

                if (!selectedPlayer) {
                    player.sendMessage('§cCouldn\'t find the selected player.');
                    return;
                }

                if (customRankName.trim() === "") {
                    player.sendMessage('§cCustom rank name cannot be empty.');
                    return;
                }

                // Menetapkan custom rank ke pemain yang dipilih
                setRank(selectedPlayer, customRankName);
                player.sendMessage(`§aSuccessfully added custom rank '${customRankName}' to ${selectedPlayer.name}`);
            }
        });
}

world.beforeEvents.chatSend.subscribe((evd) => {
    const message = evd.message;
    const player = evd.sender;
    evd.cancel = true;
    system.run(() => {
        if (message.startsWith(config.prefix)) {
            const args = message.substring(1).split(' ');
            switch (args[0]) {
                case 'setrank': {
                    if (!args[1]) return player.sendMessage('§cDefine a player. usage: §f-setrank §7<username> <rank>');
                    const plr = world.getDimension('overworld').getPlayers().find(plr => plr.name.toLowerCase() == args[1].toLowerCase());
                    if (!plr) return player.sendMessage('§cCouldn\'t find a player with that name.');
                    if (!args[2]) return player.sendMessage('§cDefine a rank. usage: §f-setrank <username> §7<rank>');
                    setRank(plr, args[2]);
                    break;
                }
                case 'list': {
                    openRankList(player);
                    break;
                }
                default: player.sendMessage(`§cUnknown command: ${message.substring(1)}. Please check that the command exists and that you have permission to use it.`);
            }
        } else {
            world.sendMessage(`[${getRank(player)}§r] ${player.name}: ${message}`);
        }
    });
});

function openRankList(player) {
    const rankListString = [...customRankList, ...uuidRanks].map(rank => `§a${rank}`).join('\n');
    const rankListUI = new ui.MessageFormData()
        .title("Custom and UUID Rank List")
        .body(rankListString)
        .button1("OK")
        .show(player);
}