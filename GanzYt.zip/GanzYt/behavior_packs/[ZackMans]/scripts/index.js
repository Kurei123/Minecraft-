/**
  * Created By ZackMans
  * https://youtube.com/@BuildTheCraft
  * FLOATING TEXT
* */
import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { getScore, commasNumbers } from "./lib/tools.js";
import { textEditor } from "./functions/floating/index.js";
import { Database } from "./lib/database.js";

const dbLb = new Database("leaderboard")

world.afterEvents.itemUse.subscribe(({ itemStack: item, source: player }) => {
if (item.typeId == "text:editor") {
if (player.isOp() ? true : player.hasTag("admin") ? true : false) {
textEditor(player)
player.playSound("random.pop", {pitch:0.4})
} else {
player.sendMessage(`§cYou are not an operator`)
player.playSound(`note.bass`)
}
}
})

world.afterEvents.entityHitEntity.subscribe(async({ hitEntity: entity, damagingEntity: player }) => {

if (!entity) return;
if (entity.typeId.includes("floating_text")) {
try {

const item = player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)
const iType = item ? item.typeId : ""

if (iType == "text:editor") {
let hasId = entity.getTags().find(v => v.includes("id:"))
let datScore = entity.getTags().find(v => v.includes('{"score":{'))
let hasScore = datScore ? JSON.parse(datScore).score.key : false
if (player.isOp() ? true : player.hasTag("admin") ? true : false) {
if (hasId) {
player.sendMessage(`§bid: §7${hasId ? hasId.slice(3) : "§cnot found"}\n§bscore: §7${hasScore ? hasScore : "§cnot found"}`)
player.runCommandAsync(`playsound random.pop @s`)
} else {
let getid = "7" + Math.random().toString(36).substr(2, 6);
entity.addTag(`id:${getid}`)
player.sendMessage(`§aSuccessfully added ID to FLOATING_TEXT "${getid}"`)
player.playSound(`random.orb`)
}
}
}

} catch {
}
}

})

var objScore = []
/* LEADERBOARD */
system.runInterval(async() => {

world.getDimension("overworld").getEntities().forEach(async(entity) => {
if (entity.typeId.includes("floating_text")) {

let tagScore = entity.getTags().find(v => v.startsWith('{"score":{'))
if (tagScore) {
let data = JSON.parse(tagScore)
for (let player of world.getPlayers()) {

let objetKey = objScore.find(v => v.object == data.score.key)
if (objetKey) {
let objectKey = objetKey.result
let isPlayer = objectKey.find(v => v.name.includes(player.name))
if (isPlayer) {
let dedf = objectKey.find(i => i.name == player.name)
var chn = objectKey.indexOf(dedf)
let Score = getScore(player, data.score.key)
let sortedLb = objectKey.sort((a, b) => b.score - a.score)
entity.nameTag = `${data.score.name}\n${
sortedLb.slice(0, 10).map((i, eje) => `\n §a#${(eje + 1)} §7${i.name} §e${commasNumbers(i.score)} `)
}`
if (dedf.score === Score) return
objectKey[chn].score = Score
} else {
let dataNye = {
name: player.name,
score: getScore(player, data.score.key)
}
objectKey.push(dataNye)
}
} else {
let dataNye = {
object: data.score.key,
result: [
{
name: player.name,
score: getScore(player, data.score.key)
}
]
}
objScore.push(dataNye)
}

}
}
}
})

})

/* FLOATING TEXT */
var currentText = 0;
system.runInterval(async() => {

world.getDimension("overworld").getEntities().forEach(async(entity) => {
if (entity.typeId.includes("floating_text")) {
let tagScore = entity.getTags().find(v => v.startsWith('{"score":{'))
let tagText = entity.getTags().filter(v => v.startsWith('text:'))
let line = "\n"

if (!tagScore) {
if (tagText) {
if (tagText.length > 1) {
for (let kt = 0; kt < tagText.length; kt++) {
entity.nameTag = `${tagText[(currentText + kt) % tagText.length].slice(5).replaceAll("(line)", line)}`
}
currentText = (currentText + 1) % tagText.length
}
if (tagText.length == 1) {
entity.nameTag = `${tagText[0].slice(5).replaceAll("(line)", line)}`
}
}
}

}
})
}, 60)