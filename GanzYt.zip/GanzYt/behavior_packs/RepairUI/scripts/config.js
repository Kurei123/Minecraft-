





/*
 * Prefix for command ".rui"
 */
export const prefix = "."

/*
 * Money price for repair, rename, and relore
 */
export const repairPrice = 10

export const renamePrice = 10

export const lorePrice = 10

/*
 * For the level price
 */
export const repairPricel = 1

export const renamePricel = 1

export const lorePricel = 1