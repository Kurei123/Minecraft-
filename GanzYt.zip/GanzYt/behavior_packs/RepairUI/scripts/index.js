import { world, system, Player } from '@minecraft/server';
import { ModalFormData, ActionFormData } from '@minecraft/server-ui';
import { repairPrice, renamePrice, lorePrice, repairPricel, renamePricel, lorePricel, prefix } from "./config.js"

function getScore(target, objective) {
  try {
    const oB = world.scoreboard.getObjective(objective);
    if (typeof target === "string") {
      const participant = oB
        .getParticipants()
        .find((pT) => pT.displayName === target);
      const score = participant ? oB.getScore(participant) : 0;
      return score === undefined ? 0 : score;
    }
    const score = oB.getScore(target.scoreboardIdentity);
    return score === undefined ? 0 : score;
  } catch {
    return 0;
  }
}

async function ForceOpen(player, form) {
	while (true) {
		const response = await form.show(player);
		if (response.cancelationReason !== "UserBusy") return response;
	}
}

function enchantListF() {
  return ['aqua_affinity', 'bane_of_arthropods', 'blast_protection', 'channeling', 'depth_strider', 'efficiency', 'feather_falling', 'fire_aspect', 'fire_protection', 'flame', 'fortune', 'frost_walker', 'impaling', 'infinity', 'knockback', 'looting', 'loyalty', 'luck_of_the_sea', 'lure', 'mending', 'multishot', 'piercing', 'power', 'projectile_protection', 'protection', 'punch', 'quick_charge', 'respiration', 'riptide', 'sharpness', 'silk_touch', 'smite', 'thorns', 'unbreaking'];
}

function IdToName(id) {
  return id.replaceAll('_', " ").toLowerCase().replace(/(^\w{1})|(\s+\w{1})/g, match => match.toUpperCase());
}

function setItem(player, item, slot) {
  const inventory = player.getComponent('inventory').container;
  inventory.setItem(slot, item);
}

function countSpec(str, separator) {
  let count = 0;
  for (let i = 0; i < str.length; i++) {
    if (str[i] == separator) {
      count += 1;
    }
  }
  return count;
}

function stringToArray(str, separator) {
  const result = [];
  for (let i = 0; i <= countSpec(str, separator); i++) {
    result.push(str.split(separator)[i]);
  }
  return result;
}

function manageEnchantments(player, item) {
  const enchantmentsList = enchantListF();
  const existingEnchantments = [];

  enchantmentsList.forEach(enchantment => {
    const enchantmentComponent = item.getComponent('minecraft:enchantments');
    if (enchantmentComponent.enchantments.hasEnchantment(enchantment) !== 0) {
      existingEnchantments.push(enchantment);
    }
  });

  existingEnchantments.forEach(enchantment => {
    system.run(() => {
      const enchantLevel = item.getComponent('minecraft:enchantments').enchantments.hasEnchantment(enchantment);
      player.runCommandAsync(`enchant @s ${enchantment} ${enchantLevel - 1}`);
    });
  });
}

world.beforeEvents.chatSend.subscribe(data => {
  const { sender, message } = data;  
  if (message.startsWith(prefix + "rui")) {
    data.cancel = true;
   system.runTimeout(() => {
    mainMenu(sender)
    }, 5)
  }
});

system.runInterval(() => {
  for (let player of world.getPlayers()) {
    if (player.hasTag("rui")) {
      mainMenu(player);
      player.runCommandAsync(`tag @s remove rui`);
    }
  }
});

async function mainMenu(player) {
         
    const ui = new ActionFormData()
    const item = player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot);
    
    if (!item) {
      player.sendMessage('§cTolong pegang item yang mau di eksekusi!')
      return;
    }

    ui.title("RepairUI")
    ui.body('§eSellect your preferred option:')
    ui.button("§l§2REPAIR\n§0Click", "textures/ui/anvil_icon")
    ui.button("§l§2RENAME\n§0Click", "textures/items/name_tag")
    ui.button("§l§2LORE\n§0Click", "textures/items/painting")
    ui.button("§4§lCLOSE MENU\n§0Click", "textures/blocks/barrier")
    let res = await ForceOpen(player, ui)

    if (res.selection === 0) {
      repair(player)
    }

    if (res.selection === 1) {
      rename(player)
    }

    if (res.selection === 2) {
      lore(player)
    }
    
    if (res.selection === 3) {
      player.sendMessage('§cThanks for visiting! created by: Nakata')
    }
}


function repair(player) {

  const ui = new ActionFormData()
  const item = player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot);

  ui.title("§l§aRepairUI  §cREPAIR");
  ui.body("§eSellect your prefrred option:")
  ui.button("§l§9REPAIR MONEY\n§0Click", "textures/ui/icon_minecoin_9x9")
  ui.button("§l§9REPAIR XP\n§0Click", "textures/items/experience_bottle")
  ui.button("§l§4TO RETURN\n§0Click", "textures/blocks/barrier")
  ui.show(player).then(res => {

    if(res.selection === 0) {
      repairMoney(player, item)
    }

    if (res.selection === 1) {
      repairLevel(player, item)
    }
    
    if (res.selection === 2) {
      mainMenu(player)
    }

  })
}

function rename(player) {

  const ui = new ActionFormData()
  const item = player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot);

  ui.title("§l§aRepairUI  §cREPAIR");
  ui.body("§eSellect your preferred option:")
  ui.button("§l§9RENAME MONEY\n§0Click", "textures/ui/icon_minecoin_9x9")
  ui.button("§l§9RENAME XP\n§0Click", "textures/items/experience_bottle")
  ui.button("§l§4TO RETURN\n§0Click", "textures/blocks/barrier")
  ui.show(player).then(res => {

    if(res.selection === 0) {
      renameMoney(player, item)
    }

    if (res.selection === 1) {
      renameLevel(player, item)
    }
    
    if (res.selection === 2) {
      mainMenu(player)
    }

  })
}

function lore(player) {

  const ui = new ActionFormData()
  const item = player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot);

  ui.title("§l§aRepairUI  §cREPAIR");
  ui.body("§eSellect your preferred option:")
  ui.button("§l§9LORE MONEY\n§0Click", "textures/ui/icon_minecoin_9x9")
  ui.button("§l§9LORE XP\n§0Click", "textures/items/experience_bottle")
  ui.button("§l§4TO RETURN\n§0Click", "textures/blocks/barrier")
  ui.show(player).then(res => {

    if(res.selection === 0) {
      loreMoney(player, item)
    }

    if (res.selection === 1) {
      loreLevel(player, item)
    }
    
    if (res.selection === 2) {}

  })
}

function repairMoney(player, item) {
    const ui = new ActionFormData();
    const money = getScore(player, 'money');

    ui.title("RepairUI | REPAIR-MONEY");

    if (item.hasComponent('minecraft:durability')) {
        const durability = item.getComponent('minecraft:durability');
        let damage = durability.damage
        let dataCost = damage * repairPrice

        ui.body(`§aHere you can repair your items with Money\n\n§eMy money: §a${money}\n§eRepair price per damage: §a${repairPrice}\n§eDamage: §c${damage}\nTotal: §a${dataCost}`);
        ui.button("§aRepair your item", "textures/ui/smithing_icon");
        ui.button("§cRETURN", "textures/blocks/barrier");
        ui.show(player).then(res => {
            if (res.selection === 0) {
                if (money < dataCost) {
                    player.sendMessage("§cUang anda tidak cukup!");
                    player.playSound("note.bass");
                } else {
                try {
                  item.getComponent('minecraft:durability').damage = item.getComponent('minecraft:durability').maxDurability - durability.maxDurability;
                     } catch (error) {}
                        setItem(player, item, player.selectedSlot);
                        player.runCommandAsync(`scoreboard players remove @s money ${dataCost}`);
                        manageEnchantments(player, item)
                }
            }
            if (res.selection === 1) {
              mainMenu(player)
            }
        });
    } else {
        ui.body("§cYour item has no durability ;-;?\n\n");
        ui.button("RETURN");
        ui.show(player);
    }
}

function repairLevel(player, item) {
    const ui = new ActionFormData();
    const level = player.level

    ui.title("RepairUI | REPAIR-LEVEL");

    if (item.hasComponent('minecraft:durability')) {
        const durability = item.getComponent('minecraft:durability');
        let damage = durability.damage
        let dataCost = damage * repairPricel

        ui.body(`§aHere you can repair your items with Money\n\n§eMy level: §a${level}\n§eRepair price per damage: §a${repairPricel}\n§eDamage: §c${damage}\n§cTotal: §a${dataCost}`);
        ui.button("§aRepair your item", "textures/ui/smithing_icon");
        ui.button("§cRETURN", "textures/blocks/barrier");
        ui.show(player).then(res => {
            if (res.selection === 0) {
                if (level < dataCost) {
                    player.sendMessage("§cLevel anda tidak cukup!");
                    player.playSound("note.bass");
                } else {
                try {
                  item.getComponent('minecraft:durability').damage = item.getComponent('minecraft:durability').maxDurability - durability.maxDurability;
                     } catch (error) {}
                        setItem(player, item, player.selectedSlot);
                        player.runCommandAsync(`xp -${dataCost}L @s`)
                        manageEnchantments(player, item)
                }
            }
            if (res.selection === 1) {
              mainMenu(player)
            }
        });
    } else {
        ui.body("§cYour item has no durability ;-;?\n\n");
        ui.button("RETURN");
        ui.show(player);
    }
}

function renameMoney(player, item) {
    const ui = new ModalFormData();
    const money = getScore(player, 'money');

        ui.title("RepairUI | RENAME-MONEY");
        ui.textField(`§aKamu dapat mengubah nama item kamu disini!\n\n§eMy Money: §a${money}\n§eRename cost: §a${renamePrice}\n\nWrite the name for your item`, "Ex: Sword Art Online");
        ui.show(player).then(res => {
             if (res.formValues[0] !== "") {
                if (money < renamePrice) {
                    player.sendMessage("§cUang anda tidak cukup!");
                    player.playSound("note.bass");
                } else {
                try {
                  item.nameTag = res.formValues[0];
                     } catch (error) {}
                        setItem(player, item, player.selectedSlot);
                        player.runCommandAsync(`scoreboard players remove @s money ${renamePrice}`);
                        manageEnchantments(player, item)
                }
             }
        });
}


function renameLevel(player, item) {
    const ui = new ModalFormData();
    const level = player.level

        ui.title("RepairUI | RENAME-LEVEL");
        ui.textField(`§aKamu dapat mengubah nama item kamu disini!\n\n§eMy Level: §a${level}\n§eRename cost: §a${renamePrice}\n\nWrite the name for your item`, "Ex: Sword Art");
        ui.show(player).then(res => {
              if (res.formValues[0] !== "") {
                if (level < renamePricel) {
                    player.sendMessage("§cUang anda tidak cukup!");
                    player.playSound("note.bass");
                } else {
                     try {
                        item.nameTag = res.formValues[0];
                         } catch (error) {}
                        setItem(player, item, player.selectedSlot);
                        player.runCommandAsync(`xp -${renamePricel}L @s`);
                        manageEnchantments(player, item)
                }
              }
        });
}

function loreMoney(player, item) {
    const ui = new ModalFormData();
    const money = getScore(player, 'money');

        ui.title("RepairUI | LORE-MONEY");
        ui.textField(`§aKamu dapat mengubah lore item kamu disini!\n\n§eMy Money: §a${money}\n§eLore cost: §a${renamePrice}\n\nWrite the name for your item`, "Ex: Sword Art Online");
        ui.show(player).then(res => {
             if (res.formValues[0] !== "") {
                if (money < lorePrice) {
                    player.sendMessage("§cUang anda tidak cukup!");
                    player.playSound("note.bass");
                } else {
                try {
                  item.setLore(stringToArray(res.formValues[0], ';'));
                     } catch (error) {}
                        setItem(player, item, player.selectedSlot);
                        player.runCommandAsync(`scoreboard players remove @s money ${lorePrice}`);
                        manageEnchantments(player, item)
                }
             }
        });
}


function loreLevel(player, item) {
    const ui = new ModalFormData();
    const level = player.level

        ui.title("RepairUI | LORE-LEVEL");
        ui.textField(`§aKamu dapat mengubah lore item kamu disini!\n\n§eMy Level: §a${level}\n§eRename cost: §a${lorePricel}\n\nWrite the name for your lore item`, "Ex: Sword Art");
        ui.show(player).then(res => {
              if (res.formValues[0] !== "") {
                if (level < lorePricel) {
                    player.sendMessage("§cUang anda tidak cukup!");
                    player.playSound("note.bass");
                } else {
                     try {
                        item.setLore(stringToArray(res.formValues[0], ';'));
                         } catch (error) {}
                        setItem(player, item, player.selectedSlot);
                        player.runCommandAsync(`xp -${lorePricel}L @s`);
                        manageEnchantments(player, item)
                }
              }
        });
}