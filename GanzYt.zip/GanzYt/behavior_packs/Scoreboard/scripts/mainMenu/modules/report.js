import { world, system, Player } from "@minecraft/server";
import { Database } from "../../@modules/Database.js";
import { ModalFormData, ActionFormData } from "@minecraft/server-ui";

const dbReports = new Database("reportsDB");


system.runInterval(() => {
     for (let player of world.getPlayers()) {
          if (player.hasTag("report")) {
               report(player);
               player.runCommandAsync(`tag @s remove report`)
               }
          }
     }
)

system.runInterval(() => {
     for (let player of world.getPlayers()) {
          if (player.hasTag("rlogs")) {
               getReports(player);
               player.runCommandAsync(`tag @s remove rlogs`)
               }
          }
     }
)

export function report(player) {
let players = world.getPlayers(); 
  let operations = [];
  let playerObjects = [];
  for (let player of players) {;
  operations.push(player.name);
  playerObjects.push(player);
  };
  
  const form = new ModalFormData()
    .title("§y§r§eReport Player")
    .dropdown("§ePlayer Name", operations)
    .textField("§cExplain Reason", "Enter Reason")

  form.show(player).then(result => {
    const playerName = operations[result.formValues[0]];
    const reason = result.formValues[1];
    
    if (reason.includes("§")) {
    player.sendMessage("§cCant use letters character");
    return;
    }

    if (playerName && reason) {
      const reportData = {
        reporter: player.name,
        reportedPlayer: playerName,
        reason: reason,
        timestamp: Date.now()
      };

      dbReports.set(player.name, reportData);

      player.sendMessage(`§aSuccessfully reported player ${playerName} for reason: ${reason}`);
    } else {
      player.sendMessage("§cPlease fill in all fields.");
    }
  });
}

export function getReports(player) {
  let reportLogs = "Report List:\n\n";

  dbReports.forEach((key, value) => {
    reportLogs += `Reporter: ${value.reporter}\n`;
    reportLogs += `Reported Player: ${value.reportedPlayer}\n`;
    reportLogs += `Reason: ${value.reason}\n`;
    reportLogs += `Timestamp: ${new Date(value.timestamp).toLocaleString()}\n\n`;
  });

  const list = new ActionFormData()
    .title("Report List ★")
    .body(reportLogs)
    .button("§l§cEXIT", "textures/ui/icon_import.png");

  list.show(player).then((response) => {});
}