import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

system.runInterval(() => {
  for (const player of world.getPlayers({
    tags: ["rank4"]
  })) {
    rank4(player);
    player.playSound("note.bell");
    player.removeTag("rank4");
  }
});

function rank4(player) {
  const ui = new ActionFormData();
  
  ui.title("§bRank List");
  ui.body("§7§•Halo Apakah Kamu Ingin Membeli Rank? Kamu Bisa Menguhubungi Owner Melalui WhatsApp,Di Bawah Ini Adalah Fitur Dan Bonus Rank KeEmpat\n\n» Night_Vision\n» Strength\n» Resistance\n» Water Brithing\n» Fire Resistance\n» Fly system");
  ui.button("Buy", "textures/ui/realms_slot_check.png"); 
  ui.button("Cancel", "textures/ui/realms_red_x.png");
  
  ui.show(player)
    .then((res) => {
      if (res.selection === 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§cBeli Rank Hubungi Owner Melalui Discord Atau Grup WhatsApp!§r"}]}`);
      }
      
      if (res.selection === 1) {
        player.addTag("rank");
      }
    })
    .catch((error) => {
      console.error("Error displaying UI:", error);
    });
}