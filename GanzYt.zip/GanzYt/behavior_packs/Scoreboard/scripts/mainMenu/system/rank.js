import { world, system, Player } from "@minecraft/server"
import { ActionFormData } from "@minecraft/server-ui"
import "./raphael/vip1";
import "./raphael/vip2";
import "./raphael/vip3";
import "./raphael/vip4";
import "./raphael/vip5";
import "./raphael/particleshop";
system.runInterval(() => {
  for (const player of world.getPlayers({
    tags: ["rank"]
  })) {
    rank(player);
    player.removeTag("rank");
  }
});

function rank(player) {
      const ui = new ActionFormData()
      
      ui.title("§eRank List")
      ui.body("§l      --------------------      \n§e              RANK LIST       \n§r§l      --------------------      \n§r§e»» §rJika ingin Membeli Rank Hubungi Owner \n§r§e»» §rIf you want to buy rank, contact the Owner ")
      ui.button("\n§010k Contact the owner", "textures/ui/promo_gift_small_green.png")
      ui.button("\n§020k Contact the owner", "textures/ui/promo_gift_small_green.png")
      ui.button("\n§030k Contact the owner", "textures/ui/promo_gift_small_green.png")
      ui.button("\n§040k Contact the owner", "textures/ui/promo_gift_small_green.png")
      ui.button("\n§050k Contact the owner", "textures/ui/promo_gift_small_green.png")
      ui.button("§l§cCLOSE", "textures/ui/cancel")
     ui.show(player).then((res) => {
 	
      if (res.selection === 0) {
         player.addTag("rank1")
      }
      
      if (res.selection === 1) {
         player.addTag("rank2")
      }
      
      if (res.selection === 2) {
         player.addTag("rank3")
      }
      
      if (res.selection === 3) {
         player.addTag("rank4")
      }
      
      if (res.selection === 4) {
         player.addTag("rank5")
      }
      	
      if (res.selection === 5) {
         player.runCommandAsync('playsound note.pling @s');
      }
    });
  }