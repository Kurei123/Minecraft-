import { world, system, Player } from "@minecraft/server"
import { ActionFormData } from "@minecraft/server-ui"

system.runInterval(() => {
  for (let player of world.getPlayers()) {
    if (player.hasTag("judi")) {
      judi(player)
      player.removeTag("judi")
    }
  }
});

function judi(player) {
  const ui = new ActionFormData()
  
  ui.title("§aJUDI HAROM")
  ui.body("§l      --------------------      \n§e             JUDI HAROM       \n§r§l      --------------------      \n§rMengapa Kalian Berjudi:( kalian Tidak Pantas Di Tiru!\n       §l§e       JUDI HAROM    ")
  ui.button("§lTARUHAN 10K\n§r§010k Click to play", "textures/items/paper.png") //0
  ui.button("§lLIST HADIAH JUDI\n§r§0Click to Open", "textures/ui/icon_cookie.png")
  ui.button("§l§cCLOSE", "textures/ui/cancel.png") //1
  ui.show(player).then((res) => {
    
    if (res.selection === 0) {
      player.runCommandAsync('tellraw @s[scores={money=..9999}] {"rawtext":[{"text":"§cTcihh Mendokseyy Duit lu kurangg Mangkanya Jangan Judi "}]}');
      player.runCommandAsync('playsound mob.villager.no @s[scores={money=..9999}]');
      player.runCommandAsync('tellraw @s[scores={money=10000..}] {"rawtext":[{"text":"§aJudi Sedang Berputar..."}]}');
      player.runCommandAsync('tag @s[scores={money=10000..}] add haram');
      player.runCommandAsync('playsound mob.villager.yes @s[scores={money=10000..}]');
      player.runCommandAsync('scoreboard Players remove @s[scores={money=10000..}] money 10000');
      player.runCommandAsync('setblock -100.52 126.00 5.65 redstone_block');
    }
    
    if (res.selection === 1) {
      listh(player);
    }
  });
}

function listh(player) {
  const ui = new ActionFormData();

  ui.title("List Hadiah");
  ui.body("§l§•§7Di Bawah Ini adalah List Hadiah Judi Harom\n1.Money 5k\n2.Money 10k\n3.Money 15k\nYang Pastinya Asa Zonk Ya Adik Adik Hehehe");
  ui.button("Kembali");

  return ui.show(player);
}