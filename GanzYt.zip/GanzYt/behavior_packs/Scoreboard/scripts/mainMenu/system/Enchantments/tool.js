import { world } from "@minecraft/server";
import { prefix_shop } from "../ShopUI/configuration.js";
import {
  ActionFormData,
  ModalFormData,
  MessageFormData,
} from "@minecraft/server-ui";

const enchantData = [
  {
    name: "Efficiency",
    max_level: 5,
    cost: 40000,
    enchant: "efficiency",
  },
  {
    name: "Fortune",
    max_level: 3,
    cost: 45000,
    enchant: "fortune",
  },
  {
    name: "Luck Of The Sea",
    max_level: 3,
    cost: 15000,
    enchant: "luck_of_the_sea",
  },
  {
    name: "Lure",
    max_level: 3,
    cost: 15000,
    enchant: "lure",
  },
  {
    name: "Silk Touch",
    max_level: 1,
    cost: 30000,
    enchant: "silk_touch",
  },
];

export function Tool(player) {
  const shop = new ActionFormData();
  shop.title(`Tool`);
  shop.body(
    `§6-------------------------------\n\nUser Information:\nName: §b${
      player.name
    }\n§6Money: §b$${getScore(
      player,
      "money"
    )}\n\n§6-------------------------------`
  );
  for (const enchant of enchantData)
    shop.button(`${enchant.name}\n§b$${enchant.cost}`);
  shop.show(player).then((result) => {
    if (result.isCanceled) return;
    const enchant = enchantData[result.selection];
    var money = getScore(player, "money");
    let brick = new ModalFormData()
      .title(`${enchant.name}`)
      .slider(
        `§6-------------------------------\n\nUser Information:\nName: §b${player.name}\n§6Money: §b$${money}\n\n§6Enchant Information:\n§6Buy x1 Level §b${enchant.name} §6= §b$${enchant.cost}\n\n§6-------------------------------\n\n§6Level`,
        1,
        enchant.max_level,
        1
      );
    brick.show(player).then((res) => {
      let dataCost = enchant.cost * res.formValues[0];
      if (res.formValues[0]) {
        player.runCommandAsync(
          `tag @s[scores={money=${dataCost}..}] add canBuy`
        );
        player.runCommandAsync(
          `scoreboard players remove @s[tag=canBuy] money ${dataCost}`
        );
        player.runCommandAsync(
          `enchant @s[tag=canBuy] ${enchant.enchant} ${res.formValues[0]}`
        );
        player.runCommandAsync(
          `tellraw @s[tag=canBuy] {"rawtext":[{"text":"§6SHOP §7>> §aSuccessfully purchased enchanted §b${enchant.name} ${res.formValues[0]} §aWith totals: §e$${dataCost}"}]}`
        );
        player.runCommandAsync(`playsound random.levelup @s[tag=canBuy]`);
        player.runCommandAsync(
          `tellraw @s[tag=!canBuy] {"rawtext":[{"text":"§6SHOP §7>> §cYour money is not enough, need §e$${dataCost} §cmoney"}]}`
        );
        player.runCommandAsync(`playsound note.bass @s[tag=!canBuy]`);
        player.runCommandAsync(`tag @s remove canBuy`);
      }
    });
  });
}

function getScore(entity, objective) {
  try {
    return world.scoreboard.getObjective(objective).getScore(entity.scoreboard);
  } catch (error) {
    return 0;
  }
}
