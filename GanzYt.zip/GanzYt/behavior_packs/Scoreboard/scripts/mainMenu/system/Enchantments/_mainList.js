/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.me
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.me/
----------------------------------
*/

import { world, system, Player } from "@minecraft/server";
import {
  ActionFormData,
  ModalFormData,
  MessageFormData,
} from "@minecraft/server-ui";
import { AllPurpose } from "./all_purpose.js";
import { Armor } from "./armor.js";
import { MeleeWeapon } from "./melee_weapon.js";
import { RangedWeapon } from "./ranged_weapon.js";
import { Tool } from "./tool.js";

system.runInterval(() => {
  for (let player of world.getPlayers()) {
    if (player.hasTag("es")) {
      Enchantments(player);
      player.runCommandAsync(`tag @s remove es`);
    }
  }
});

export function Enchantments(player) {
  const gui = new ActionFormData()
    .title(`Enchantments`)
    .body(
      `§6-------------------------------\n\nUser Information:\nName: §b${
        player.name
      }\n§6Money: §b$${getScore(
        player,
        "money"
      )}\n\n§6-------------------------------`
    )
    .button(`All Purpose`, "textures/items/book_enchanted.png")
    .button(`Armor`, "textures/items/iron_chestplate.png")
    .button(`Melee Weapon`, "textures/items/iron_sword.png")
    .button(`Ranged Weapon`, "textures/items/bow_pulling_2.png")
    .button(`Tool`, "textures/items/iron_pickaxe.png");
  gui.show(player).then((result) => {
    if (result.selection == 0) {
      AllPurpose(player);
    }
    if (result.selection == 1) {
      Armor(player);
    }
    if (result.selection == 2) {
      MeleeWeapon(player);
    }
    if (result.selection == 3) {
      RangedWeapon(player);
    }
    if (result.selection == 4) {
      Tool(player);
    }
    if (result.selection == 5) {}
  });
}

function getScore(entity, objective) {
  try {
    return world.scoreboard.getObjective(objective).getScore(entity.scoreboard);
  } catch (error) {
    return 0;
  }
}
