import { world, Player, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { ForceOpen } from "../Function/index.js";
import { TpaSystem } from "./system/wibuu.js"
import { rules } from "./system/rules.js"
import { starter } from "./system/starter.js"
import { HomeSystem } from "./system/home.js"
import { Bank } from "./system/atm.js"
import { redeemCode } from "./system/code.js";
import { Enchantments } from "./system/Enchantments/_mainList.js";
import "./system/warp.js"
import { Wing } from "./system/wings.js";
import { list } from "./modules/list.js"; 
import { report } from "./modules/report.js"
import { review } from "./modules/review.js"
import { daily } from "./modules/dailylogin.js";
import "./system/rank.js"
import "./system/judi.js"
import "./system/sizeui.js"

import { ShopUI } from "./system/ShopUI/shop_main.js"


world.beforeEvents.itemUse.subscribe((eventData) => {
  let item = eventData.itemStack;
  let player = eventData.source;
  if (item.typeId == "mcc:hs") {
    system.run(() => {
      playerMenu(player);
    });
  }
});

async function playerMenu(player) {
  let f = new ActionFormData()
    .title("§y§r§eSERVER UI ")
    .body("§l            \n§e             SERVER MENU       \n§r§l            \n§r§e»» §rSilahkan Pilih Menu Kalian\n§r§e»» §rBuy Map Di RaphaelMC Langsung\n       §l§e       SERVER MENU    ")
    .button("World Warp\n§0Click to Open", "textures/ui/worldsIcon.png")
    .button("Sethome\n§0Click to Open", "textures/ui/icon_recipe_item.png")
    .button("Teleport\n§0Click to Open", "textures/ui/dressing_room_customization.png")
    .button("Redem Code\n§0Click to Open", "textures/ui/icon_blackfriday.png")
    .button("Shop Gui\n§0Click to Open", "textures/ui/store_home_icon.png")
     .button("Bank System\n§0Click to Open", "textures/ui/icon_book_writable.png")
    .button("Wings System\n§0Click to Open", "textures/items/elytra.png")    
    .button("Skills\n§0Click to Open", "textures/ui/debug_glyph_color.png")
    .button("Starterkit\n§0Click to Open", "textures/ui/icon_recipe_equipment.png")
    .button("§l§cCLOSE\n§r§0Click to Close", "textures/ui/cancel.png");

  let r = await ForceOpen(player, f);

  if (r.canceled) return console.warn("close ui");

  switch (r.selection) {
    case 0:
      // If "World Warp" is selected, show the second UI
      player.addTag("warps")
      break;
    case 1:
      HomeSystem(player);
      break;
    case 2:
      TpaSystem(player);
      break;
    case 3:
    redeemCode(player);
      break;
    case 4:
      ShopUI(player);
      break;
    case 5:
      Bank(player);
      break;
     case 6:
      Wing(player);
      break;
     case 7:
      player.addTag("skil")
      break;
    case 8:
      starter(player); 
      break;	
  }
}

export { playerMenu };