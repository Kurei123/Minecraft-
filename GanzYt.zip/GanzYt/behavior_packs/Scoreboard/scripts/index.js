import "./mainMenu/player.js";
import "./mainMenu/settings.js";