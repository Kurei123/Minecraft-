const Config = {
  /* 
  Scoreboard Config!!
  Change the scoreboard config as you like 
  */
  serverName: "Your server name",
  serverIp: "your server ip",
  maxPlayer: "10",
  //Objectives Config 
  objectives: "money",
  //Prefix for custom command 
  prefix: "+",
  //Version 
  version: "9.0.0-beta",
  // Change to true when your world crashes
  disableWatchDog: true, 
};

export {
  Config
}