import { world, system } from "@minecraft/server";
import { npcEditor } from "./functions/npc/index.js";
const prefix = "."

world.afterEvents.entityHitEntity.subscribe(async(data) => {
const {
hitEntity: entity,
damagingEntity: player
} = data
if (!entity) return;
if (entity.typeId.includes("npc")) {
try {
const item = player.getComponent("minecraft:inventory").container.getItem(player.selectedSlot)
const iType = item ? item.typeId : ""
let hasCmd = entity.getTags().find(v => v.includes("cmd:"))
let getCmd = entity.getTags().filter(v => v.includes("cmd:"))
let hasClick = entity.getTags().find(v => v.includes("click:"))
let hasId = entity.getTags().find(v => v.includes("id:"))
if (iType == "npc:editor") {
if (player.isOp() ? true : player.hasTag("admin") ? true : false) {
if (hasId) {
player.sendMessage(`§bid: §7${hasId ? hasId.slice(3) : "§cnot found"}\n§bclick: §7${hasClick ? hasClick.slice(6) : "§cnot found"}`)
player.runCommandAsync(`playsound random.pop @s`)
} else {
let getid = "7" + Math.random().toString(36).substr(2, 6);
entity.addTag(`id:${getid}`)
player.sendMessage(`§aSuccessfully added ID to NPC "${getid}"`)
player.playSound(`random.orb`)
}
}
} else if (hasClick) {
if (hasCmd) {
for (let i of getCmd) {
player.runCommandAsync(i.slice(4))
}
}

// Added commands
if (entity.hasTag("click:diamond")) {
// menuUi(player) // Can open the UI
player.runCommandAsync(`give @s diamond 2`)
player.runCommandAsync(`playsound random.orb @s`)
player.sendMessage(`${entity.nameTag}\n\n${entity.name}`)
} else if (entity.hasTag("click:menu")) {
player.runCommandAsync(`give @s glass`)
player.playSound(`random.orb`)
}

}
} catch {
}
}
})

let ticks = 0;
let currentColorIndex = 0;
const colorCodes = ["§c", "§6", "§e", "§a", "§b", "§d"];
system.runInterval(async() => {
world.getDimension("overworld").getEntities().forEach(async(entity) => {
if (entity.typeId.includes("npc")) {
let name = entity.getTags().find(v => v.includes("name:"))
if (name) {
ticks++;
let line = "\n"
if (ticks < 3) {
var codesn = "§r"
} else if (ticks >= 3) {
codesn = ""
ticks = 0;
}
let prefixName = name.slice(5).split("(line)")[0] ? name.slice(5).split("(line)")[0] : name.slice(5)
var nameTag = prefixName.startsWith("(rainbow)") ? "" : prefixName.startsWith("(rainbow_run)") ? "" : prefixName
if (prefixName.startsWith("(rainbow)") ? true : prefixName.startsWith("(rainbow_run)") ? true : false) {
let awName = prefixName.replaceAll("(rainbow)", "").replaceAll("(rainbow_run)", "")
for (let i = 0; i < awName.length; i++) {
nameTag += colorCodes[(currentColorIndex + i) % colorCodes.length] + awName[i];
}
}
let lineName = name.slice(5).split("(line)")[1] ? `\n` + name.split("(line)")[1] : ""
entity.nameTag = `${nameTag}${lineName.replaceAll("(line)", line).replace("(pcount)", `${world.getAllPlayers().length}`).replace("(pcount_nether)", `${world.getDimension("nether").getPlayers().length}`).replace("(pcount_the_end)", `${world.getDimension("the_end").getPlayers().length}`).replace("(pcount_overworld)", `${world.getDimension("overworld").getPlayers().length}`)}` + codesn
if (prefixName.startsWith("(rainbow_run)")) {
currentColorIndex = (currentColorIndex + 1) % colorCodes.length;
}
}
}
})
}, 10)

world.afterEvents.itemUse.subscribe((eventData) => {
const {
itemStack: item,
source: player
} = eventData
if (item.typeId == "npc:editor") {
if (player.isOp() ? true : player.hasTag("admin") ? true : false) {
npcEditor(player)
player.playSound("random.pop", {pitch:0.4})
} else {
player.sendMessage(`§cYou are not an operator`)
player.playSound(`note.bass`)
}
}
})