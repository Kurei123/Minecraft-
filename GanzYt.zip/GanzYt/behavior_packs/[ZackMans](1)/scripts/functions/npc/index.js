import { world, system } from "@minecraft/server"
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui"

export function npcEditor(player) {
let gui = new ModalFormData()
let operations = []
let entityObjects = []
world.getDimension(player.dimension.id).getEntities().forEach(async(entity) => {
if (entity.typeId.includes("npc")) {
let etags = entity.getTags().find(v => v.includes("id:"))
if (etags) {
operations.push(etags.slice(3))
entityObjects.push(entity)
}
}
})
gui.title(`NPC EDITOR`)
gui.dropdown("Select one of the NPCs with the ID below to edit", operations)
gui.show(player).then(async(res) => {
if (res.canceled) return
let target = entityObjects[res.formValues[0]]
if (target) {
editorMenu(player, target)
}
})
}

function editorMenu(player, target) {
let hasClick = target.getTags().find(v => v.includes("click:"))
let getCmd = target.getTags().filter(v => v.includes("cmd:"))
let hasId = target.getTags().find(v => v.includes("id:"))
let hasName = target.getTags().find(v => v.includes("name:"))
let gui = new ActionFormData()
.title(`NPC EDITOR`)
.body(`§c${Math.floor(target.location.x)} ${Math.floor(target.location.y)} ${Math.floor(target.location.z)}\n§bid: §7${hasId ? hasId.slice(3) : "§cnot found"}\n§bclick: §7${hasClick ? hasClick.slice(6) : "§cnot found"}\n§bcmd: §7${getCmd ? getCmd.length : "§cnot found"}\n§bname: §7${hasName ? hasName.slice(5) : "§cnot found"}`)
.button(`Change Codename\n§r§oClick To Open`)
.button(`Command Editor\n§r§oClick To Open`)
.button(`Change Name\n§r§oClick To Open`)
.button(`Teleport Coordinate\n§r§oClick To Open`)
.show(player).then(async(resy) => {
if (resy.selection == 0) {
codeName(player, target)
}
if (resy.selection == 1) {
selectCmd(player, target)
}
if (resy.selection == 2) {
changeName(player, target)
}
if (resy.selection == 3) {
tpCoordinate(player, target)
}
})
}

function tpCoordinate(player, target) {
let gui = new ModalFormData()
.title(`NPC EDITOR`)
.textField(`§cEnter the text "@s" to teleport npc to you`, `Enter coordinate`)
.show(player).then(async(res) => {
if (res.canceled) return
let args = res.formValues[0].trim().split(/ +/).slice(1)
if (res.formValues[0] == "@s") {
target.runCommandAsync(`tp @s ${player.name}`)
} else if (!args[1]) {
player.sendMessage(`§cPlease enter the coordinates correctly`)
player.playSound(`note.bass`)
} else if (isNaN(res.formValues[0].split(" ")[0])) {
player.sendMessage(`§cPlease enter the coordinates correctly`)
player.playSound(`note.bass`)
} else if (isNaN(args[0])) {
player.sendMessage(`§cPlease enter the coordinates correctly`)
player.playSound(`note.bass`)
} else if (isNaN(args[1])) {
player.sendMessage(`§cPlease enter the coordinates correctly`)
player.playSound(`note.bass`)
} else {
target.runCommandAsync(`tp @s ${res.formValues[0]}`)
player.sendMessage(`§aSuccessfully teleported npc to coordinates ${res.formValues[0]}`)
player.playSound(`random.orb`)
}
})
}

function changeName(player, target) {
let hasName = target.getTags().find(v => v.includes("name:"))
let gui = new ModalFormData()
.title(`NPC EDITOR`)
.textField(`§d(pcount) (pcount_overworld) (pcount_nether) (pcount_the_end) §7to see online players\n§d(rainbow_run) §7running rainbow colors\n§d(rainbow) §7rainbow colors remain\n§d(line) §7for the line in the text name\n\n§bname: §7${hasName ? hasName.slice(5) : "§cnot found"}`, `Change Name`)
.show(player).then(async(res) => {
if (res.canceled) return
if (hasName) {
target.removeTag(hasName)
target.addTag(`name:${res.formValues[0]}`)
player.sendMessage(`§aSuccessfully changed the name from "${hasName.slice(5)}§r§a" to "${res.formValues[0]}§r§a"`)
player.playSound(`random.orb`)
} else {
target.addTag(`name:${res.formValues[0]}`)
player.sendMessage(`§aSuccessfully add the name "${res.formValues[0]}§r§a"`)
player.playSound(`random.orb`)
}
})
}

function selectCmd(player, target) {
let getCmd = target.getTags().filter(v => v.includes("cmd:"))
let gui = new MessageFormData()
.title(`NPC EDITOR`)
.body(`Select add command or delete command`)
.button1(`add`)
.button2(`remove`)
.show(player).then(async(result) => {
if (result.selection == 0) {
let form = new ModalFormData()
.title(`NPC EDITOR`)
.slider(`NPC already has ${getCmd.length} commands, how many commands do you want to add to NPC?`, 1, 10, 1)
.show(player).then(async(res) => {
if (res.canceled) return
if (res.formValues[0]) {
addCmd(player, target, res.formValues[0])
}
})
}
if (result.selection == 1) {
removeCmd(player, target)
}
})
}

function removeCmd(player, target) {
let gui = new ModalFormData()
let getCmd = target.getTags().filter(v => v.includes("cmd:"))
let hasCmd = target.getTags().find(v => v.includes("cmd:"))
if (!hasCmd) {
player.sendMessage(`§cNo commands listed yet`)
player.playSound("note.bass")
return
}
let operations = []
let entityCmd = []
for (let i of getCmd) {
operations.push(i.slice(4))
entityCmd.push(i)
}
gui.title(`NPC EDITOR`)
gui.dropdown("choose who you want to visit", operations)
gui.show(player).then(async(res) => {
if (res.canceled) return
let removeCmd = entityCmd[res.formValues[0]]
if (removeCmd) {
target.removeTag(`${removeCmd}`)
player.sendMessage(`§aSuccessfully deleted command "${removeCmd}"`)
player.playSound("random.orb")
}
})
}

function addCmd(player, target, countCmd) {
let getCmd = target.getTags().filter(v => v.includes("cmd:"))
if (getCmd.length + countCmd > 10) {
player.sendMessage(`§cYou chose too many commands, the npc now has ${getCmd.length} commands and you chose ${countCmd} commands if added up to ${getCmd.length + countCmd} which is more than the maximum number of 10 commands`)
player.playSound(`note.bass`)
return
}
let gui = new ModalFormData()
gui.title(`NPC EDITOR`)
for (let i = 0; i < countCmd; i++) {
gui.textField(`§cCommand ${i + 1}`,`Add Command`)
}
gui.show(player).then(async(res) => {
if (res.canceled) return
let sCmd = 0
for (let i = 0; i < countCmd; i++) {
if (target.hasTag(`cmd:${res.formValues[i]}`)) {
player.sendMessage(`§cThe ${i+1}th command containing "${res.formValues[i]}" is already in the command list`)
player.playSound("note.bass")
} else {
target.addTag(`cmd:${res.formValues[i]}`)
sCmd += 1
}
}
player.sendMessage(`§aSuccessfully added ${sCmd} commands`)
player.playSound(`random.orb`)
})
}

function codeName(player, target) {
let hasClick = target.getTags().find(v => v.includes("click:"))
let hasId = target.getTags().find(v => v.includes("id:"))
let gui = new ModalFormData()
.title(`NPC EDITOR`)
.textField(`§bid: §7${hasId.slice(3)}\n§bclick: §7${hasClick ? hasClick.slice(6) : "§cnot found"}`, `Change codename`)
.show(player).then(async(res) => {
if (res.canceled) return
if (res.formValues[0].startsWith("click:")) {
if (hasClick) {
player.sendMessage(`§aSuccessfully changed the codename from "${hasClick}" to "${res.formValues[0]}"`)
player.playSound(`random.orb`)
target.removeTag(hasClick)
target.addTag(res.formValues[0])
} else {
player.sendMessage(`§aSuccessfully added codename "${res.formValues[0]}"`)
player.playSound(`random.orb`)
target.addTag(res.formValues[0])
}
} else {
player.sendMessage(`§cStart with "click:" without quotation marks`)
player.playSound(`note.bass`)
}
})
}