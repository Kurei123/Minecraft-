import "./main.js";
import "./data.js";
import "./scoreboard.js";
import "./chat.js";
import "./nametag.js";

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
