import { world, system } from "@minecraft/server";
import { getScore } from "../function/getScore.js";
import { getPlaceholder } from "../function/getPlaceholder.js";
import { metricNumbers } from "../function/metricNumbers.js";
import { hour, minute, day, month, year } from "../function/getDate.js";
import { ScoreboardDB } from "../board/data.js";
import { getRank } from "../function/getRank.js";
import { getClan } from "../function/getClan.js";
import { board } from "../board/_config.js";

const placeholder = (player) => {
  return [
    {
      NAME: player.name,
      CURRENCY: ScoreboardDB.get("ScoreboardDBConfig-currency") ?? "$",
      MONEY: metricNumbers(
        getScore(
          player,
          ScoreboardDB.get("ScoreboardDBConfig-default-money") ?? "money"
        )
      ),
      RANK: getRank(player),
      CLAN: getClan(player),
      HEALTH: Math.round(player.getComponent("minecraft:health").currentValue),
      LEVEL: player.level,
      XP: player.getTotalXp(),
      KILL: getScore(player, "kill"),
      DEATH: getScore(player, "death"),
      ONLINE: Array.from(world.getPlayers()).length,
      MAXON: ScoreboardDB.get("ScoreboardDBConfig-max-online") ?? 2023,
      HOUR: hour,
      MINUTE: minute,
      DAY: day,
      MONTH: month,
      YEAR: year,
      DIMENSION: player.dimension.id
        .replace("minecraft:", "")
        .replace("_", " ")
        .replace(/\b\w/g, (c) => c.toUpperCase()),
      X: Math.floor(player.location.x),
      Y: Math.floor(player.location.y),
      Z: Math.floor(player.location.z),
      BLANK: " ",
    },
  ];
};

system.runInterval((ick) => {
  for (let player of world.getPlayers()) {
    player.onScreenDisplay.setTitle(
      getPlaceholder(board.Line.join("\n"), placeholder(player))
    );
    player.runCommandAsync(`scoreboard objectives add money dummy`);
    player.runCommandAsync(`scoreboard objectives add death dummy`);
    player.runCommandAsync(`scoreboard objectives add kill dummy`);

    let playerHealt = player.getComponent("minecraft:health").currentValue;
    let isDeath = player.hasTag("death");
    if (playerHealt == 0 && isDeath == false) {
      player.addTag("death");
      player.runCommandAsync(`scoreboard players add @s death 1`);
      player.runCommandAsync(`scoreboard players add @p kill 1`);
    } else if (playerHealt > 0) {
      player.removeTag("death");
    }
  }
}, 0);

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
