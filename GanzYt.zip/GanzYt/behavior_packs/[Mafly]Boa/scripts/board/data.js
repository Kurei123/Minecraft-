import { Database } from "../function/Database.js";

const ScoreboardDB = new Database("ScoreboardDB");
const RankDB = new Database("RankDB");
const ClanDB = new Database("ClanDB");
const ChatDB = new Database("ChatDB");
const NametagDB = new Database("NametagDB");

export { ScoreboardDB, RankDB, ClanDB, ChatDB, NametagDB };

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
