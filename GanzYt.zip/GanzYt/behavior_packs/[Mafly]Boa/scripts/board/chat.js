import { world, system } from "@minecraft/server";
import { getPlaceholder } from "../function/getPlaceholder";
import { ChatDB } from "./data.js";
import { getRank } from "../function/getRank.js";
import { getClan } from "../function/getClan.js";

world.beforeEvents.chatSend.subscribe((data) => {
  const player = data.sender;
  data.cancel = true;

  const placeholder = [
    {
      NAME: player.name,
      RANK: getRank(player),
      CLAN: getClan(player),
      MSG: data.message,
    },
  ];

  if (ChatDB.get("ChatDBDisplay-status") === true) {
    world.sendMessage(
      getPlaceholder(
        ChatDB.get("ChatDBDisplay-chat") ??
          "§8[§r@RANK§8] §8[§r@CLAN§8] §7@NAME >>§r @MSG",
        placeholder
      )
    );
  } else {
    world.sendMessage(getPlaceholder("<@NAME> @MSG", placeholder));
  }
});
/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
