/**
 LIST PLACEHOLDER
 * @BLANK = Blank line
 * @NAME = Get player name
 * @CURRENCY = Get currency money
 * @MONEY = Get count of money
 * @RANK = Get player rank
 * @CLAN = Get player clan
 * @HEALTH = Get player health
 * @LEVEL = Get player level experience
 * @XP = Get player total experience
 * @KILL = Get count kill player
 * @DEATH = Get count death player
 * @ONLINE = Get count player online
 * @MAXON = Get count max online
 * @HOUR = Get time in hour
 * @MINUTE = Get time in minute
 * @DAY = Get time in day
 * @MONTH = Get time in month
 * @YEAR = Get time in year
 * @DIMENSION = Get player dimension
 * @X = Get X player position
 * @Y = Get Y player position
 * @Z = Get Z player position\n\n
 */

//Line of Scoreboard, you can add more line here
const board = {
  Line: [
    "@BLANK",
    "  §r§kii§r SERVER NAME §r§kii§r  ",
    "@BLANK",
    "§rName : §r⩇ §7@NAME",
    "§7Money : §r@CURRENCY§e@MONEY",
    "§7Level :§r ⩀ §r@LEVEL",
    "§7Death : §r @DEATH",
    "@BLANK",
    "§rServer Stats :",
    "§7Online: §r §a@ONLINE§r/§3@MAXON",
    "§7Dimension: §r @DIMENSION",
  ],
};

export { board };

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
