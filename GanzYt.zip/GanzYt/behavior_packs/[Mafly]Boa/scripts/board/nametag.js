import { world, system } from "@minecraft/server";
import { getPlaceholder } from "../function/getPlaceholder";
import { NametagDB } from "./data.js";
import { getRank } from "../function/getRank.js";
import { getClan } from "../function/getClan.js";
/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
