import { world, system } from "@minecraft/server";
import {
  ActionFormData,
  MessageFormData,
  ModalFormData,
} from "@minecraft/server-ui";
import { ForceOpen } from "../function/ForceOpen.js";
import { ScoreboardDB, RankDB, ClanDB, ChatDB, NametagDB } from "./data.js";

system.beforeEvents.watchdogTerminate.subscribe((event) => {
  event.cancel = true;
  console.warn(
    `[Watchdog] Canceled critical exception of type '${event.cancelationReason}`
  );
});

world.beforeEvents.itemUse.subscribe((eventData) => {
  let item = eventData.itemStack;
  let player = eventData.source;
  if (item.typeId == "ms:board") {
    system.run(() => {
      FuncBoardConfig(player);
    });
  }
});

async function FuncBoardConfig(player) {
  const UI = new ActionFormData()
    .title("Board Configuration")
    .button("Scoreboard Config", "textures/ui/gear")
    .button("Rank Config", "textures/ui/gear")
    .button("Clan Config", "textures/ui/gear")
    .button("Chat Display", "textures/ui/gear")
    .button("Nametag Display", "textures/ui/gear")
    .button("All Config Reset", "textures/ui/refresh_hover");
  let result = await ForceOpen(player, UI);
  if (result.canceled) return;
  if (result.selection == 0) {
    FuncScbConfig(player);
  }
  if (result.selection == 1) {
    FuncRankConfig(player);
  }
  if (result.selection == 2) {
    FuncClanConfig(player);
  }
  if (result.selection == 3) {
    FuncChatDisplay(player);
  }
  if (result.selection == 4) {
    FuncNametagDisplay(player);
  }
  if (result.selection == 5) {
    FuncAllConfigReset(player);
  }
}

async function FuncScbConfig(player) {
  const UI = new ModalFormData()
    .title("Scoreboard Config Setting")
    .textField(
      "§6Currency",
      "$",
      ScoreboardDB.get("ScoreboardDBConfig-currency") ?? "$"
    )
    .textField(
      "§6Default Money",
      "money",
      ScoreboardDB.get("ScoreboardDBConfig-default-money") ?? "money"
    )
    .textField(
      "§6Max Online",
      "2023",
      ScoreboardDB.get("ScoreboardDBConfig-max-online") ?? "2023"
    )
    .textField(
      "§6Offset Timezone (UTC -12 to +12)",
      "+7",
      ScoreboardDB.get("ScoreboardDBConfig-offset-timezone") ?? "+7"
    );
  let result = await ForceOpen(player, UI);
  if (result.canceled) return;
  if (result.formValues[0]) {
    ScoreboardDB.set("ScoreboardDBConfig-currency", result.formValues[0]);
  }
  if (result.formValues[1]) {
    ScoreboardDB.set("ScoreboardDBConfig-default-money", result.formValues[1]);
  }
  if (result.formValues[2]) {
    ScoreboardDB.set("ScoreboardDBConfig-max-online", result.formValues[2]);
  }
  if (result.formValues[3]) {
    const offsetInput = result.formValues[3];
    const offsetRegex = /^([+-]?\d+)$/;

    if (
      offsetRegex.test(offsetInput) &&
      (offsetInput.includes("+") || offsetInput.includes("-"))
    ) {
      const offsetValue = parseInt(offsetInput);

      if (!isNaN(offsetValue) && offsetValue >= -12 && offsetValue <= 12) {
        ScoreboardDB.set(
          "ScoreboardDBConfig-offset-timezone",
          result.formValues[3]
        );
        player.sendMessage(
          "§cSYSTEM §7>> §aScoreboard config has been updated"
        );
        player.playSound("random.pop");
      } else {
        player.sendMessage(
          "§cSYSTEM §7>> §cInvalid offset value. Please enter a number between -12 and +12"
        );
        player.playSound("note.bass");
      }
    } else {
      player.sendMessage(
        "§cSYSTEM §7>> §cInvalid input. Please enter a valid number with optional '+' or '-' sign"
      );
      player.playSound("note.bass");
    }
  }
}

async function FuncRankConfig(player) {
  const UI = new ModalFormData()
    .title("Rank Config Setting")
    .textField(
      "§6Rank prefix",
      "rank:",
      RankDB.get("RankDBConfig-prefix") ?? "rank:"
    )
    .textField(
      "§6Rank default",
      "§aMember",
      RankDB.get("RankDBConfig-default") ?? "§aMember"
    );
  let result = await ForceOpen(player, UI);
  if (result.canceled) return;
  if (result.formValues[0]) {
    RankDB.set(`RankDBConfig-prefix`, result.formValues[0]);
  }
  if (result.formValues[1]) {
    RankDB.set(`RankDBConfig-default`, result.formValues[1]);
  }
  player.sendMessage(
    "§cSYSTEM §7>> §aRank config has been updated" +
      result.formValues[0] +
      result.formValues[1]
  );
  player.playSound("random.pop");
}

async function FuncClanConfig(player) {
  const UI = new ModalFormData()
    .title("Clan Config Setting")
    .textField(
      "§6Clan prefix",
      "clan:",
      ClanDB.get("ClanDBConfig-prefix") ?? "clan:"
    )
    .textField(
      "§6Clan default",
      "§fNone",
      ClanDB.get("ClanDBConfig-default") ?? "§fNone"
    );
  let result = await ForceOpen(player, UI);
  if (result.canceled) return;
  if (result.formValues[0]) {
    ClanDB.set(`ClanDBConfig-prefix`, result.formValues[0]);
  }
  if (result.formValues[1]) {
    ClanDB.set(`ClanDBConfig-default`, result.formValues[1]);
  }
  player.sendMessage("§cSYSTEM §7>> §aClan config has been updated");
  player.playSound("random.pop");
}

async function FuncChatDisplay(player) {
  const UI = new ModalFormData()
    .title("Chat Display Setting")
    .textField(
      "\n§b@NAME §7Get player name\n§b@RANK §7Get player rank\n§b@CLAN §7Get player clan\n§b@MSG §7Get player send message\n\n§6Display Chat",
      "§8[§r@RANK§8] §8[§r@CLAN§8] §7@NAME >>§r @MSG",
      ChatDB.get("ChatDBDisplay-chat") ??
        "§8[§r@RANK§8] §8[§r@CLAN§8] §7@NAME >>§r @MSG"
    )
    .toggle("§6Enable custom chat", ChatDB.get("ChatDBDisplay-status"));
  let result = await ForceOpen(player, UI);
  if (result.canceled) return;
  if (result.formValues[0]) {
    ChatDB.set(`ChatDBDisplay-chat`, result.formValues[0]);
  }
  if (result.formValues[1] == true) {
    ChatDB.set(`ChatDBDisplay-status`, true);
  }
  if (result.formValues[1] == false) {
    ChatDB.set(`ChatDBDisplay-status`, false);
  }
  player.sendMessage("§cSYSTEM §7>> §aChat display has been updated");
  player.playSound("random.pop");
}

async function FuncNametagDisplay(player) {
  const UI = new ModalFormData()
    .title("Nametag Display Setting")
    .textField(
      "\n§b@NL §7Add new line\n§b@NAME §7Get player name\n§b@RANK §7Get player rank\n§b@CLAN §7Get player clan\n\n§6Display Nametag",
      "§8[§r@RANK§8] §f@NAME@NL§r§8[§r@CLAN§8]",
      NametagDB.get("NametagDBDisplay-nametag") ??
        "§8[§r@RANK§8] §f@NAME@NL§r§8[§r@CLAN§8]"
    )
    .toggle(
      "§6Enable custom nametag",
      NametagDB.get("NametagDBDisplay-status")
    );
  let result = await ForceOpen(player, UI);
  if (result.canceled) return;
  if (result.formValues[0]) {
    NametagDB.set(`NametagDBDisplay-nametag`, result.formValues[0]);
  }
  if (result.formValues[1] == true) {
    NametagDB.set(`NametagDBDisplay-status`, true);
  }
  if (result.formValues[1] == false) {
    NametagDB.set(`NametagDBDisplay-status`, false);
  }
  player.sendMessage("§cSYSTEM §7>> §aNametag display has been updated");
  player.playSound("random.pop");
}

async function FuncAllConfigReset(player) {
  const UI = new ModalFormData()
    .title("All Config Reset")
    .toggle("Reset Scoreboard config")
    .toggle("Reset Rank config")
    .toggle("Reset Clan config")
    .toggle("Reset Chat Display")
    .toggle("Reset Nametag Display");
  let result = await ForceOpen(player, UI);
  if (result.canceled) return;
  if (result.formValues[0] === true) {
    ScoreboardDB.clear();
    player.sendMessage("§cSYSTEM §7>> §6Scoreboard config has been reset");
  }
  if (result.formValues[1] === true) {
    RankDB.clear();
    player.sendMessage("§cSYSTEM §7>> §6Rank config has been reset");
  }
  if (result.formValues[2] === true) {
    ClanDB.clear();
    player.sendMessage("§cSYSTEM §7>> §6Clan config has been reset");
  }
  if (result.formValues[3] === true) {
    ChatDB.clear();
    player.sendMessage("§cSYSTEM §7>> §6Chat display has been reset");
  }
  if (result.formValues[4] === true) {
    NametagDB.clear();
    player.sendMessage("§cSYSTEM §7>> §6Nametag display has been reset");
  }
  if (
    result.formValues[0] === false &&
    result.formValues[1] === false &&
    result.formValues[2] === false &&
    result.formValues[3] === false &&
    result.formValues[4] === false
  ) {
    player.sendMessage("§cSYSTEM §7>> §6No configuration reset");
  } else {
    player.sendMessage(
      "§cSYSTEM §7>> §6The selected config Board has been reset, §6please run §b/reload"
    );
  }
  player.playSound("random.pop");
}

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
