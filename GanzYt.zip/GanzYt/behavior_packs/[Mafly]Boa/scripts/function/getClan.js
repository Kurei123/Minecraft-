import { ClanDB } from "../board/data.js";

function getClan(player) {
  const prefix = ClanDB.get("ClanDBConfig-prefix") ?? "clan:";

  const ranks = player
    .getTags()
    .filter((v) => v.startsWith(prefix))
    .map((v) => v.substring(prefix.length))
    .filter((x) => x);

  let rank;
  if (ranks.length === 0) {
    rank = ClanDB.get("ClanDBConfig-default") ?? "§fNone";
  } else {
    rank = ranks.join("§r");
  }

  return rank;
}

export { getClan };

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
