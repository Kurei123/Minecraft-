import "./Database.js";
import "./ForceOpen.js";
import "./getDate.js";
import "./getPlaceholder.js";
import "./getScore.js";
import "./metricNumbers.js";
import "./getRank.js";
import "./getClan.js";

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
