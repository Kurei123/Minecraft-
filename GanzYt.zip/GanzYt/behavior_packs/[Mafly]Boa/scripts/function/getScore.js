import { world } from "@minecraft/server";

function getScore(entity, objective) {
  try {
    return (
      world.scoreboard
        .getObjective(objective)
        .getScore(entity.scoreboardIdentity) ?? 0
    );
  } catch (error) {
    return 0;
  }
}

export { getScore };

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
