import { ScoreboardDB } from "../board/data.js";
import { system } from "@minecraft/server";

var day, month, year, hour, minute;

system.runInterval((tick) => {
  var currentDate = new Date(
    Date.now() +
      parseInt(ScoreboardDB.get("ScoreboardDBConfig-offset-timezone") ?? "+7") *
        3600000
  );
  var months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];

  day = String(currentDate.getDate()).padStart(2, "0");
  month = months[currentDate.getMonth()];
  year = String(currentDate.getFullYear());
  hour = String(currentDate.getHours()).padStart(2, "0");
  minute = String(currentDate.getMinutes()).padStart(2, "0");
}, 0);

export { day, month, year, hour, minute };

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
