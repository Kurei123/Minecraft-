import { RankDB } from "../board/data.js";

function getRank(player) {
  const prefix = RankDB.get("RankDBConfig-prefix") ?? "rank:";

  const ranks = player
    .getTags()
    .filter((v) => v.startsWith(prefix))
    .map((v) => v.substring(prefix.length))
    .filter((x) => x);

  let rank;
  if (ranks.length === 0) {
    rank = RankDB.get("RankDBConfig-default") ?? "§aMember";
  } else {
    rank = ranks.join("§r");
  }

  return rank;
}

export { getRank };

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
