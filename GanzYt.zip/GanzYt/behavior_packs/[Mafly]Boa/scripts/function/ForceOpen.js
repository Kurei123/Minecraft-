import { system } from "@minecraft/server";
import { FormCancelationReason } from "@minecraft/server-ui";

system.beforeEvents.watchdogTerminate.subscribe((event) => {
  event.cancel = true;
  console.warn(
    `[Watchdog] Canceled critical exception of type '${event.cancelationReason}`
  );
});

async function ForceOpen(player, form, timeout = Infinity) {
  const startTick = system.currentTick;
  while (system.currentTick - startTick < timeout) {
    const response = await form.show(player);
    if (response.cancelationReason !== FormCancelationReason.UserBusy) {
      return response;
    }
  }
  throw new Error(`Timed out after ${timeout} ticks`);
}

export { ForceOpen };

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
