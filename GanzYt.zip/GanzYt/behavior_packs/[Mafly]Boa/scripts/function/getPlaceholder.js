function getPlaceholder(text, data) {
  for (const item of data) {
    for (const key in item) {
      if (item.hasOwnProperty(key)) {
        const placeholder = new RegExp("@" + key, "g");
        text = text.replace(placeholder, item[key]);
      }
    }
  }
  return text;
}

export { getPlaceholder };

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
