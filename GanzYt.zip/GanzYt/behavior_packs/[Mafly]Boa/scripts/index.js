import "./function/_load.js";
import "./board/_load.js";

/*
----------------------------------
Creator: Mafly
Discord:
https://dsc.mafly-studio.xyz
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly-studio.xyz/
----------------------------------
*/
