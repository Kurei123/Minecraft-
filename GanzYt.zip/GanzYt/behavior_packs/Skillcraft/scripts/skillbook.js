
import { world, system } from "@minecraft/server";
import { runCommandArray, _score, booleanOutput, removeLmao } from './asa-script';
import { ActionFormData } from '@minecraft/server-ui';

world.afterEvents.chatSend.subscribe((eventData) => {
    if (eventData.message.toLowerCase().split(' ')[0] === '+skill') {
        eventData.cancel = true;
        Book(eventData.sender)
    }
});

system.runInterval(() => {
    for (let player of world.getPlayers()) {
        if (player.hasTag("skil")) {
            Book(player);
            player.runCommandAsync(`tag @s remove skil`);
        }
    }
});
const asaText = ['${asaLmao}', '']
const asaLmao = asaText[removeLmao]

const form = new ActionFormData()
    .title(`Skillbook`)
    .body(`Choose skills to upgrade`)
    .button(`Attacking`, `textures/ui/strength_effect`)
    .button(`Mining`, `textures/ui/haste_effect`)
    .button(`Gathering`, `textures/items/stone_axe`)
    .button(`Defense`, `textures/ui/resistance_effect`)
    .button(`Agility`, `textures/items/bow_pulling_2`)
    .button(`Magic`, `textures/items/blaze_powder`)
    .button(`Farmer`, `textures/items/diamond_hoe`)
    .button(`Skills (1)`, `textures/ui/strength_effect`);

async function Book(player) {
    let result = await new Promise((res, rej) => {
        let count = 0;
        const loop = async () => {
            const data = await form.show(player).catch(e => {
                rej(e);
                return void 0;
            })
            if (data.canceled && data.cancelationReason === 'UserClosed') {
                player.sendMessage("§cThao tác bị hủy do người dùng");
                res();
            }
            system.runTimeout(() => {
                if (count <= 15 && data.canceled && data.cancelationReason !== 'UserClosed') {
                    loop();
                    count++;
                } else if (count > 15)
                    rej('player không hợp tác')
                else
                    rej();

            }, 10)
            if (!data.canceled) res(data);
        }
        loop();
    }).catch(e => console.warn(e));

    if (result.selection !== undefined)
        switch (result.selection) {
            case 0:
                Sword(player);
                break;
            case 1:
                Pickaxe(player);
                break;
            case 2:
                Tool1(player);
                break;
            case 3:
                Defend1(player);
                break;
            case 4:
                Agility1(player);
                break;
            case 5:
                Magic(player);
                break;
            case 6:
                Mino(player);
                break;
            case 7:
                Skills(player);
                break;
        }

    player.runCommandAsync(`tag @s remove book`);
    player.runCommandAsync(`playsound item.book.page_turn`);
}

function Magic(player) {
    const form = new ActionFormData()
        .title(`Magic`)
        .body(`+ Your level: ${player.level}`)
        .button(`Upgrade (Your level: ${_score(player, `magic`)})`)
        .button(`§8Back`)
    form.show(player).then(result => {
        if (player.level > 4) {
            if (result.selection === 0) {
                player.runCommandAsync(`scoreboard players add @s magic 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'magic') + 1} skill for Magic!§r`)

                Magic(player)
            }
            if (result.selection === 1) {
                Book(player)
            }
        } else {
            world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 5 to be able to continue upgrading!`)
        }
    })
}
function Agility1(player) {
    const form = new ActionFormData()
        .title(`Faster`).body(`+ Your level: ${player.level}`)
        .button(`Bow (Your level: ${_score(player, `bow`)})`, `textures/items/bow_pulling_0`)
        .button(`boots (Your level: ${_score(player, `boots`)})`, `textures/items/chainmail_boots`)
        .button(`Elytra (Your level: ${_score(player, `elytra`)})`, `textures/items/elytra`)
        .button(`Back`)
    form.show(player).then(result => {
        if (player.level > 4) {
            if (result.selection === 0) {
                player.runCommandAsync(`scoreboard players add @s bow 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'bow') + 1} skill for Bow!§r`)
                Agility1(player)
            }
            if (result.selection === 1) {
                player.runCommandAsync(`scoreboard players add @s boots 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'boots') + 1} skill for boots!§r`)
                Agility1(player)
            }

            if (result.selection === 2) {
                player.runCommandAsync(`scoreboard players add @s elytra 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'elytra') + 1} skill for Elytra!§r`)
                Agility1(player)
            }
            if (result.selection === 3) {
                Book(player)
            }
        } else {
            world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 5 to be able to continue upgrading!`)
        }
    })
}
function Mino(player) {
    const form = new ActionFormData()
        .title(`Farmer`).body(`+ Your level: ${player.level}`)
        .button(`Hoe (Your level: ${_score(player, `farmer`)})`, `textures/items/diamond_hoe`)
        .button(`Seeds (Your level: ${_score(player, `wheat`)})`, `textures/items/carrot`)
        .button(`Back`)
    form.show(player).then(result => {
        if (player.level > 4) {
            if (result.selection === 0) {
                player.runCommandAsync(`scoreboard players add @s farmer 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'farmer') + 1} skill for Hoe!§r`)
                Mino(player)
            }
            if (result.selection === 1) {
                player.runCommandAsync(`scoreboard players add @s wheat 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'wheat') + 1} skill for Seeds!§r`)
                Mino(player)
            }
            if (result.selection === 2) {
                Book(player)
            }
        } else {
            world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 5 to be able to continue upgrading!`)
        }
    })
}
function Defend1(player) {
    const form = new ActionFormData()
        .title(`Defend`).body(`+ Your level: ${player.level}`)
        .button(`Helmet (Your level: ${_score(player, `helmet`)})`, `textures/items/iron_helmet`)
        .button(`Chestplate (Your level: ${_score(player, `chestplate`)})`, `textures/items/iron_chestplate`)
        .button(`Leggings (Your level: ${_score(player, `leggings`)})`, `textures/items/iron_leggings`)
        .button(`Shield (Your level: ${_score(player, `shield`)})`, `textures/items/iron_ingot`)
        .button(`Back`)
    form.show(player).then(result => {
        if (player.level > 4) {
            if (result.selection === 0) {
                player.runCommandAsync(`scoreboard players add @s helmet 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'helmet') + 1} skill for Helmet!§r`)
                Defend1(player)
            }
            if (result.selection === 1) {
                player.runCommandAsync(`scoreboard players add @s chestplate 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'chestplate') + 1} skill for Chestplate!§r`)
                Defend1(player)
            }
            if (result.selection === 2) {
                player.runCommandAsync(`scoreboard players add @s leggings 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`tag @s remove book`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'leggings') + 1} skill for Leggings!§r`)
                Defend1(player)
            }
            if (result.selection === 3) {
                player.runCommandAsync(`scoreboard players add @s shield 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`tag @s remove book`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'shield') + 1} skill for Shield!§r`)
                Defend1(player)
            }
            if (result.selection === 4) {
                Book(player)
            }
        } else {
            world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 5 to be able to continue upgrading!`)
        }
    })
}
function Pickaxe(player) {
    const form = new ActionFormData()
        .title(`Mining`).body(`+ Your level: ${player.level}`)
        .button(`Upgrade (Your level: ${_score(player, `pickaxe`)})`, `textures/items/diamond_pickaxe`)
        .button(`Back`)
    form.show(player).then(result => {
        if (player.level > 4) {
            if (result.selection === 0) {
                player.runCommandAsync(`scoreboard players add @s pickaxe 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'pickaxe') + 1} skill for Mining!§r`)
                Pickaxe(player)
            }
            if (result.selection === 1) {
                Book(player)
            }
        } else {
            world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 5 to be able to continue upgrading!`)
        }
    })
}
function Sword(player) {
    const form = new ActionFormData()
        .title(`Attacking`).body(`+ Your level: ${player.level}`)
        .button(`Sword (Your level: ${_score(player, `sword`)})`, `textures/items/iron_sword`)
        .button(`Trident (Your level: ${_score(player, `trident`)})`, `textures/items/trident`)
        .button(`Back`)
    form.show(player).then(result => {
        if (player.level > 4) {
            if (result.selection === 0) {
                player.runCommandAsync(`scoreboard players add @s sword 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'sword') + 1} skill for Sword!§r`)
                Sword(player)
            }
            if (result.selection === 1) {
                player.runCommandAsync(`scoreboard players add @s trident 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'trident') + 1} skill for Trident!§r`)
                Sword(player)
            }
            if (result.selection === 2) {
                Book(player)
            }
        } else {
            world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 5 to be able to continue upgrading!`)
        }
    })
}

function Skills(player) {
    const form = new ActionFormData()
        .title(`Skills`)
        .body(`+ Your level: ${player.level}`)
        .button(`Movement (Your level: ${_score(player, `speed`)})`, `textures/ui/speed_effect`)
        .button(`Underwater movement (Your level: ${_score(player, `unspeed`)})`, `textures/ui/speed_effect`)
        .button(`Hunger  (Your level: ${_score(player, `def`)})`, `textures/ui/hunger_effect`)
        .button(`Perfect chance (Your level: ${_score(player, `arrow`)})`, `textures/items/arrow`)
        .button(`Health (Your level: ${_score(player, `h`)})`, `textures/ui/health_boost_effect`)
        .button(`Tough  (${booleanOutput(player.getTags().includes(`cungran`), "Already owned", "Not yet owned")})`, `textures/ui/resistance_effect`)
        .button(`Miner (${booleanOutput(player.getTags().includes(`miner`), "Already owned", "Not yet owned")})`, `textures/items/diamond_pickaxe`)
        .button(`Sturdy (${booleanOutput(player.getTags().includes(`cuongtrang`), "Already owned", "Not yet owned")})`, `textures/ui/resistance_effect`)
        .button(`§8Back`)
    form.show(player).then(result => {
        if (result.selection === 0) {
            if (player.level > 9) {
                runCommandArray(player, [
                    `scoreboard players add @s speed 1`,
                    `xp -10l`,
                    `say §o§b${asaLmao}${player.name} has upgraded ${_score(player, 'speed') + 1} skill for Movement !§r`
                ], true)
                Skills(player)
            } else {
                if (player.level < 9) {
                    world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 10 to be able to continue the upgrade!`)
                }
            }
        }
        if (result.selection === 1) {
            if (player.level > 9) {
                runCommandArray(player, [
                    `scoreboard players add @s unspeed 1`,
                    `xp -10l`,
                    `say §o§b${asaLmao}${player.name} has upgraded ${_score(player, 'unspeed') + 1} skill for Underwater movement!§r`
                ], true)
                Skills(player)
            } else {
                if (player.level < 9) {
                    world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 10 to be able to continue the upgrade!`)
                }
            }
        }
        if (result.selection === 2) {
            if (player.level > 9) {
                runCommandArray(player, [
                    `scoreboard players add @s def 1`,
                    `xp -10l`,

                    `say §o§b${asaLmao}${player.name} has upgraded ${_score(player, 'def') + 1} skill forHunger!§r`
                ], true)
                Skills(player)
            } else {
                if (player.level < 9) {
                    world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 10 to be able to continue the upgrade!`)
                }
            }
        }
        if (result.selection === 3) {
            if (player.level > 9) {
                runCommandArray(player, [
                    `scoreboard players add @s arrow 1`,
                    `xp -10l`,
                    `say §o§b${asaLmao}${player.name} has upgraded ${_score(player, 'arrow') + 1} skill for Perfect chance!§r`
                ], true)
                Skills(player)
            } else {
                if (player.level < 9) {
                    world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 10 to be able to continue the upgrade!`)
                }
            }
        }
        if (result.selection === 4) {
            if (player.level > 9) {
                runCommandArray(player, [
                    `scoreboard players add @s h 1`,

                    `xp -10l`,
                    `say §o§b${asaLmao}${player.name} has upgraded ${_score(player, 'h') + 1} skill for Health!§r`
                ], true)
                Skills(player)
            }
            else {
                if (player.level < 9) {
                    world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 10 to be able to continue the upgrade!`)
                }
            }
        }

        if (result.selection === 5) {
            if (player.getTags().includes(`cungran`)) {
                world.sendMessage(`§o§4You've upgraded this skill already§r`)
            } else {
                if (player.level < 20) {
                    world.sendMessage(`§o§4YOU NEED LEVEL 20 OR HIGHER TO CONTINUE WITH THE UPGRADE§r`)
                }
                else {

                    player.addLevels(-20)
                    player.addTag(`cungran`)
                    world.sendMessage(`§o§b${asaLmao}${player.name} has unlocked skill Tough !§r`)

                    world.sendMessage(`§o§b${asaLmao}${player.name} This skill makes you immune to mining fatigue , slowness effect and will run fast when in spider silk!§r`)

                    Skills(player)
                }
            }
        }
        if (result.selection === 6) {
            if (player.getTags().includes(`miner`)) {
                world.sendMessage(`§o§4You've upgraded this skill already§r`)
            } else {
                if (player.level < 12) {
                    world.sendMessage(`§o§4YOU NEED LEVEL 12 OR HIGHER TO CONTINUE UPGRADE§r`)
                } else {
                    player.addLevels(-12)
                    player.addTag(`miner`)
                    world.sendMessage(`§o§b${asaLmao}${player.name} has unlocked skill Miner!§r`)

                    world.sendMessage(`§o§b${asaLmao}${player.name} This skill will increase the amount of experience from digging ores such as iron, gold....!§r`)

                    Skills(player)
                }
            }
        }
        if (result.selection === 7) {
            if (player.getTags().includes(`cuongtrang`)) {
                world.sendMessage(`§o§4You've upgraded this skill already§r`)
            } else {
                if (player.level < 24) {
                    world.sendMessage(`§o§4YOU NEED LEVEL 24 OR HIGHER TO CONTINUE UPGRADE§r`)
                } else {
                    player.addLevels(-24)
                    player.addTag(`cuongtrang`)
                    world.sendMessage(`§o§b${asaLmao}${player.name} has unlocked skill Sturdy!§r`)
                    world.sendMessage(`§o§b${asaLmao}${player.name} This skill helps you not to be slowed down when equipping iron armor, gold, netherite, anvil§r`)

                    Skills(player)
                }
            }
        }
        if (result.selection === 8) {
            Book(player)
        }
    })
}
function Tool1(player) {
    const form = new ActionFormData()
        .title(`Gathering`).body(`+ Your level: ${player.level}`)
        .button(`Axe (Your level: ${_score(player, `axe`)})`, `textures/items/iron_axe`)
        .button(`Fishing rod (Your level: ${_score(player, `fishing_rod`)})`, `textures/items/fishing_rod_cast`)
        .button(`Shears (Your level: ${_score(player, `shears`)})`, `textures/items/shears`)
        .button(`Shovel (Your level: ${_score(player, `shovel`)})`, `textures/items/iron_shovel`)
        .button(`Back`)
    form.show(player).then(result => {
        if (player.level > 4) {
            if (result.selection === 0) {
                player.runCommandAsync(`scoreboard players add @s axe 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'axe') + 1} skill for Axe!§r`)

                Tool1(player)
            }
            if (result.selection === 1) {
                player.runCommandAsync(`scoreboard players add @s fishing_rod 1`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'fishing_rod') + 1} skill for Fishing rod!§r`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                Tool1(player)
            }
            if (result.selection === 2) {
                player.runCommandAsync(`scoreboard players add @s shears 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'shears') + 1} skill for Shears!§r`)
                Tool1(player)
            }
            if (result.selection === 3) {
                player.runCommandAsync(`scoreboard players add @s shovel 1`)
                player.runCommandAsync(`xp -5l @s`)
                player.runCommandAsync(`playsound item.book.page_turn`)
                world.sendMessage(`§o§b${asaLmao}${player.name} has upgraded ${_score(player, 'shovel') + 1} skill for Shovel!§r`)
                Tool1(player)
            } if (result.selection === 4) { Book(player) }
        } else {
            world.sendMessage(`§4You cannot upgrade because you do not have enough experience, the minimum level must be 5 to be able to continue upgrading!`)
        }
    })
}
