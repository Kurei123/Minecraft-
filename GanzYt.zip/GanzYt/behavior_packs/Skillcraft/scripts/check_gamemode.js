import { world } from "@minecraft/server";

class ASYNCMETHOD {
    /*
     * yeah just run command
     * @param {string} command command need to run
     * @param {Entity | Player | Null} selector that run command (for @s)
     * @return {CommandResult}
     */
    static async runCommand(command, selector, dim = __overworld) {
        try {
            if (selector) dim = selector;
            const r = await dim.runCommandAsync(command);
            return {
                data: r,
                error: false
            }
        } catch (e) {
            if (G.cmd_error) world.debug(e)
            return {
                error: true,
                statusMessage: `[runCommand]-§cError: ${e}`
            };
        }
    }
    static async runCommands(commands, selector) {
        /**in dev*/
        try {
            if (selector) commands.forEach(cmd => runCommand(cmd, selector));
            else commands.forEach(cmd => runCommand(cmd));
        } catch (e) { world.debug(e) }
    }
    /*
     * return current gamemode for player
     * @param {Player} player player need to check gamemode
     * @return {Gamemode}
     */
    static async getGamemode(player) {
        const data = await Promise.all([
            ASYNCMETHOD.runCommand(`testfor @s[m=survival]`),
            ASYNCMETHOD.runCommand(`testfor @s[m=creative]`),
            ASYNCMETHOD.runCommand(`testfor @s[m=adventure]`),
            ASYNCMETHOD.runCommand(`testfor @s[m=spectator]`)
        ]),
            r = ["survival", "creative", "adventure", "spectator"];
        return r[data.findIndex(v => !v.error)] ?? void 0;
    }
    /*
     * set gamemode for player
     * @param {Player} player player need to set gamemode
     * @param {Gamemode} gamemode
     * @return {Boolean} Is setting gamemode successful?
     */
    static async setGamemode(player, gamemode) {
        const o = await ASYNCMETHOD.getGamemode(player);
        if (gamemode === o) return false;
        await ASYNCMETHOD.runCommand(`gamemode s @s`, player);
        return true;
    }
}

export { ASYNCMETHOD }