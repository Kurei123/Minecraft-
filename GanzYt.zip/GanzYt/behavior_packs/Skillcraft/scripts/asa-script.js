import { world, system } from "@minecraft/server";
function _score(_player, _scoreboardName) {
    const getScoreboard = world.scoreboard.getObjective(_scoreboardName)
    for (const scoreboardItem of getScoreboard.getScores())
        if (scoreboardItem.participant.displayName === _player.scoreboardIdentity?.displayName)
            return getScoreboard.getScore(_player.scoreboardIdentity);
    return 0
}
function booleanOutput(booleanValue, onTrue, onFalse) { return booleanValue ? onTrue : onFalse }
function runCommandArray(player, commandList, removeSay) {
    try {
        if ("object" != typeof commandList)
            throw `Cannot use type ${typeof commandList}`; if (!commandList.length)
            throw "Cannot use type Object"; for (const commandItem of commandList) removeSay && commandItem.split(" ").includes("say") ? world.sendMessage(commandItem.replace("execute as @s[tag=lvl20] run say ", "").replace("execute as @s[tag=lvl10] run say ", "".replace("execute as @s[tag=lvl20] run say ", "").replaceAll("@s", ""))) : player.runCommandAsync(commandItem)
    } catch (error) { console.warn(error) }
} class debug { static typeofObject(value) { return "object" == typeof value ? value.length ? "array" : "object" : typeof value } } class asaScript { static blockList(blocklist, blockcheck) { try { if ("array" === debug.typeofObject(blocklist)) { if ("string" == typeof blockcheck) return blocklist.includes(blockcheck); throw "blockcheck is not string" } if ("string" === debug.typeofObject(blocklist)) return blocklist === blockcheck; throw `Cannot use data type ${debug.typeofObject(blocklist)} in blocklist` } catch (e) { console.warn(e) } } static randomRun(change, runFunction) { try { if ("number" == typeof change) { if ("function" == typeof runFunction) { const randomNumber = Math.floor(Math.random() * change); return 0 === randomNumber && system.runTimeout(runFunction, 1), !0 } throw "runFuntion must be a function" } throw "change must be a number" } catch (e) { console.warn(e) } } static randomLoop(change, runFunction) { try { if ("number" == typeof change) { if ("function" == typeof runFunction) { const randomNumber = Math.floor(Math.random() * change); for (let index = 0; index < randomNumber + 1; index++)system.runTimeout(runFunction, 1); return !0 } throw "runFuntion must be a function" } throw "change must be a number" } catch (e) { console.warn(e) } } } const removeLmao = 1; export { asaScript, debug, _score, booleanOutput, runCommandArray, removeLmao };