import { SpawnTp } from "../system/spawntp.js";
import { HomeSystem } from "../system/home.js";
import { mainLevel } from "../system/leveling.js";
import { TpaSystem } from "../system/tpa.js";
import { Warp } from "../system/warp.js";
import { ShopSystem } from "../system/shop.js";
import { redeemCode } from "../system/code.js";
import { report } from "../system/report.js";
import { showLandMenu } from "../JUSTSKYLAND_NPERMA/land.js";

export const buttons = [
    {
        id: "spawnTp",
        display: "§r[ Teleport Spawn ]",
        icon: "textures/items/spawn.png",
        handler: SpawnTp
    },
    {
        id: "home",
        display: "§r[ Home System ]",
        icon: "textures/items/home.png",
        handler: HomeSystem
    },
    {
        id: "tpa",
        display: "§r[ Tpa System ]",
        icon: "textures/items/tpa.png",
        handler: TpaSystem
    },
    {
        id: "level",
        display: "§r[ Leveling System ]",
        icon: "textures/items/levelup.png",
        handler: mainLevel
    },
    {
        id: "code",
        display: "§r[ Redeem Code ]",
        icon: "textures/items/redeem.png",
        handler: redeemCode
    },
    {
        id: "report",
        display: "§r[ Report Players ]",
        icon: "textures/items/report.png",
        handler: report
    },
    {
        id: "land",
        display: "§r[ Land Management ]",
        icon: "textures/ui/xyz_axis.png",
        handler: showLandMenu
    },
];

export const color = "§a";
export const disableColor = "§4";
export const disableText = "feature has disabled";
export const disableIcon = "textures/blocks/barrier";