import { world, system } from "@minecraft/server"
import { getScore, getRank } from "./lib/game.js";
import "./mainMenu/admin.js";
import "./mainMenu/players.js";
import "./mainMenu/buttons.js";
import { prefix } from "./config.js";

//System Import\\
import "./system/lag.js";
import "./JUSTSKYLAND_NPERMA/system.js";

world.beforeEvents.chatSend.subscribe(data => {
  const { sender, message } = data;   
  let prefix = "."
  if (message.startsWith(prefix + "menu")) {
    data.cancel = true;
   system.runTimeout(() => {
    sender.runCommandAsync('give @s mcc:menu')
   }, 1)
  }
});