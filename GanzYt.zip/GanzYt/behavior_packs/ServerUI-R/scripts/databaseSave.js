import { Database } from "./@modules/Database.js"

//SETTING
export const ServerSetDB = new Database("settingDB");

export const commandCooldown = [];