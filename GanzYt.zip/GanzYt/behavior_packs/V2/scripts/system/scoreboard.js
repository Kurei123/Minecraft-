import { world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { system } from "@minecraft/server";
import { getScore } from "../lib/game.js";

system.runInterval(() => {
    for (let player of world.getPlayers()) {
        if (player.hasTag("in")) {
            Incubator(player);
            player.runCommandAsync(`tag @s remove in`);
        }
    }
});

function Incubator(player) {
    // Mendapatkan jumlah incubator yang dimiliki pemain dari sistem skor
    const incubatorScore = getScore(player, 'incubator');

    const form = new ActionFormData()
        .title("Incubator")
        .body(`§l\n§e» §rWelcome to Incubator RaphaelMC\n§e§l» §rIncubator : ${incubatorScore}`)
        .button('§lSpin 50k Money\n§r§0Click to play', 'textures/items/incu.png')
        .button('§lIncubator 1\n§r§0Change the incubator', 'textures/items/trident.png')
        .button('§lIncubator 2\n§r§0Change the incubator', 'textures/items/netherite_chestplate.png')
        .button('§l§cKEMBALI', 'textures/ui/cancel');

    form.show(player).then(result => {
        if (result.selection === 0) {
            // Logika untuk aksi saat pemain memilih Spin 50k Money
            player.runCommandAsync('tellraw @s[scores={money=..49999}] {"rawtext":[{"text":"§cMaaf, Money Anda tidak Cukup Untuk Memulai Incubator"}]}');
            player.runCommandAsync('playsound mob.villager.no @s[scores={money=..49999}]');
            player.runCommandAsync('tellraw @s[scores={money=50000..}] {"rawtext":[{"text":"§aSpin Sedang di Lakukan..."}]}');
            player.runCommandAsync('tag @s[scores={money=50000..}] add incu');
            player.runCommandAsync('playsound mob.villager.yes @s[scores={money=50000..}]');
            player.runCommandAsync('scoreboard players remove @s[scores={money=500000..}] money 50000');
            player.runCommandAsync('setblock -55.54 126.00 4.34 redstone_block');
        } else if (result.selection === 1) {
            // Logika untuk aksi saat pemain memilih Incubator 1
            const incubator1Form = new ActionFormData()
                .title("Incubator 1")
                .body(`Jumlah Incubator Kamu:§a ${incubatorScore}`)
                .button("§lTotem\n§r§0Change 1 Incubator", "textures/items/totem.png")
                .button("§lTrident\n§r§0Change 2 Incubator", "textures/items/trident.png")
                .button("§lElytra\n§r§0Change 3 Incubator", "textures/items/elytra.png")
                .button("§l100 XP Bottle\n§r§0Change 5 Incubator", "textures/items/experience_bottle.png")
                .button("§l§cKEMBALI", "textures/ui/cancel");

            incubator1Form.show(player).then(incubator1Result => {
                // Lakukan sesuatu berdasarkan pilihan Incubator 1
                switch (incubator1Result.selection) {
                    case 0:
            player.runCommandAsync('tellraw @s[scores={incubator=..0}] {"rawtext":[{"text":"§cMaaf, incubator Anda Tidak cukup"}]}');
            player.runCommandAsync('playsound mob.villager.no @s[scores={incubator=..0}]');
            player.runCommandAsync('tellraw @s[scores={incubator=1..}] {"rawtext":[{"text":"§aBerhasil Menukar Incubator.."}]}');
            player.runCommandAsync('give @s[scores={incubator=1..}] totem_of_undying');
            player.runCommandAsync('playsound mob.villager.yes @s[scores={incubator=1..}]');
             player.runCommandAsync('scoreboard players remove @s[scores={incubator=1..}] incubator 1');
              player.runCommandAsync('summon fireworks_rocket ~~~'); 
                        break;
                    case 1:
            player.runCommandAsync('tellraw @s[scores={incubator=..1}] {"rawtext":[{"text":"§cMaaf, incubator Anda Tidak cukup"}]}');
            player.runCommandAsync('playsound mob.villager.no @s[scores={incubator=..1}]');
            player.runCommandAsync('tellraw @s[scores={incubator=2..}] {"rawtext":[{"text":"§aBerhasil Menukar Incubator.."}]}');
            player.runCommandAsync('give @s[scores={incubator=2..}] trident');
            player.runCommandAsync('playsound mob.villager.yes @s[scores={incubator=2..}]');
            player.runCommandAsync('scoreboard players remove @s[scores={incubator=2..}] incubator 2');
             player.runCommandAsync('summon fireworks_rocket ~~~'); 
                        break;
                    case 2:
            player.runCommandAsync('tellraw @s[scores={incubator=..2}] {"rawtext":[{"text":"§cMaaf, incubator Anda Tidak cukup"}]}');
            player.runCommandAsync('playsound mob.villager.no @s[scores={incubator=..2}]');
            player.runCommandAsync('tellraw @s[scores={incubator=3..}] {"rawtext":[{"text":"§aBerhasil Menukar Incubator.."}]}');
            player.runCommandAsync('give @s[scores={incubator=3..}] elytra');
            player.runCommandAsync('playsound mob.villager.yes @s[scores={incubator=3..}]');
            player.runCommandAsync('scoreboard players remove @s[scores={incubator=3..}] incubator 3');
             player.runCommandAsync('summon fireworks_rocket ~~~'); 
                        break;
                    case 3:            
            player.runCommandAsync('tellraw @s[scores={incubator=..4}] {"rawtext":[{"text":"§cMaaf, incubator Anda Tidak cukup"}]}');
            player.runCommandAsync('playsound mob.villager.no @s[scores={incubator=..4}]');
            player.runCommandAsync('tellraw @s[scores={incubator=5..}] {"rawtext":[{"text":"§aBerhasil Menukar Incubator.."}]}');
            player.runCommandAsync('give @s[scores={incubator=5..}] experience_bottle 100');
            player.runCommandAsync('playsound mob.villager.yes @s[scores={incubator=5..}]');
            player.runCommandAsync('scoreboard players remove @s[scores={incubator=5..}] incubator 5');
             player.runCommandAsync('summon fireworks_rocket ~~~'); 
                        break;
                    default:
              player.runCommandAsync('tag @s add in');
              player.runCommandAsync('playsound note.bell @s');
                        break;
                }
            }).catch(incubator1Error => {
                console.error("Error showing Incubator 1 form:", incubator1Error);
            });
        } else if (result.selection === 2) {
            // Logika untuk aksi saat pemain memilih Incubator 2
            const incubator2Form = new ActionFormData()
                .title("Incubator 2")
                .body(`Jumlah Incubator Kamu: §a${incubatorScore}`)
                .button("§lNetherite Helmet\n§r§0Change 2 Incubator", "textures/items/netherite_helmet.png")
                .button("§lNetherite Chestplate\n§r§0Change 2 Incubator", "textures/items/netherite_chestplate.png")
                .button("§lNetherite Leggings\n§r§0Change 2 Incubator", "textures/items/netherite_leggings.png")
                .button("§lNetherite Boots\n§r§0Change 2 Incubator", "textures/items/netherite_boots.png")
                .button("§l§cKEMBALI", "textures/ui/cancel");

            incubator2Form.show(player).then(incubator2Result => {
                // Lakukan sesuatu berdasarkan pilihan Incubator 2
                switch (incubator2Result.selection) {
                    case 0:
            player.runCommandAsync('tellraw @s[scores={incubator=..1}] {"rawtext":[{"text":"§cMaaf, incubator Anda Tidak cukup"}]}');
            player.runCommandAsync('playsound mob.villager.no @s[scores={incubator=..1}]');
            player.runCommandAsync('tellraw @s[scores={incubator=2..}] {"rawtext":[{"text":"§aBerhasil Menukar Incubator.."}]}');
            player.runCommandAsync('give @s[scores={incubator=2..}] netherite_helmet');
            player.runCommandAsync('playsound mob.villager.yes @s[scores={incubator=2..}]');
            player.runCommandAsync('scoreboard players remove @s[scores={incubator=2..}] incubator 2');
             player.runCommandAsync('summon fireworks_rocket ~~~'); 
                        break;
                    case 1:
            player.runCommandAsync('tellraw @s[scores={incubator=..1}] {"rawtext":[{"text":"§cMaaf, incubator Anda Tidak cukup"}]}');
            player.runCommandAsync('playsound mob.villager.no @s[scores={incubator=..1}]');
            player.runCommandAsync('tellraw @s[scores={incubator=2..}] {"rawtext":[{"text":"§aBerhasil Menukar Incubator.."}]}');
            player.runCommandAsync('give @s[scores={incubator=2..}] netherite_chestplate');
            player.runCommandAsync('playsound mob.villager.yes @s[scores={incubator=2..}]');
            player.runCommandAsync('scoreboard players remove @s[scores={incubator=2..}] incubator 2');
             player.runCommandAsync('summon fireworks_rocket ~~~'); 
                        break;
                    case 2:
            player.runCommandAsync('tellraw @s[scores={incubator=..1}] {"rawtext":[{"text":"§cMaaf, incubator Anda Tidak cukup"}]}');
            player.runCommandAsync('playsound mob.villager.no @s[scores={incubator=..1}]');
            player.runCommandAsync('tellraw @s[scores={incubator=2..}] {"rawtext":[{"text":"§aBerhasil Menukar Incubator.."}]}');
            player.runCommandAsync('give @s[scores={incubator=2..}] netherite_leggings');
            player.runCommandAsync('playsound mob.villager.yes @s[scores={incubator=2..}]');
            player.runCommandAsync('scoreboard players remove @s[scores={incubator=2..}] incubator 2');
             player.runCommandAsync('summon fireworks_rocket ~~~'); 
                        break;
                    case 3:
            player.runCommandAsync('tellraw @s[scores={incubator=..1}] {"rawtext":[{"text":"§cMaaf, incubator Anda Tidak cukup"}]}');
            player.runCommandAsync('playsound mob.villager.no @s[scores={incubator=..1}]');
            player.runCommandAsync('tellraw @s[scores={incubator=2..}] {"rawtext":[{"text":"§aBerhasil Menukar Incubator.."}]}');
            player.runCommandAsync('give @s[scores={incubator=2..}] netherite_boots');
            player.runCommandAsync('playsound mob.villager.yes @s[scores={incubator=2..}]');
            player.runCommandAsync('scoreboard players remove @s[scores={incubator=2..}] incubator 2');
             player.runCommandAsync('summon fireworks_rocket ~~~'); 
                        break;
                    default:
              player.runCommandAsync('tag @s add in');
              player.runCommandAsync('playsound note.bell @s');
                        break;
                }
            }).catch(incubator2Error => {
                console.error("Error showing Incubator 2 form:", incubator2Error);
            });
        }
    }).catch(error => {
        console.error("Error showing Incubator form:", error);
    });
}